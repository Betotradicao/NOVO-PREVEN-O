/**
 * Intelbras NetSDK FFI Wrapper para Node.js
 * Documentação: NetSDK Programming Guide
 */
declare enum EM_LOGIN_SPAC_CAP_TYPE {
    EM_LOGIN_SPEC_CAP_TCP = 0,// TCP login
    EM_LOGIN_SPEC_CAP_ANY = 1,// Auto mode
    EM_LOGIN_SPEC_CAP_SERVER_CONN = 2,// Actively register
    EM_LOGIN_SPEC_CAP_MULTICAST = 3,// Multicast
    EM_LOGIN_SPEC_CAP_UDP = 4,// UDP
    EM_LOGIN_SPEC_CAP_MAIN_CONN_ONLY = 6,// Only main connection
    EM_LOGIN_SPEC_CAP_SSL = 7,// SSL
    EM_LOGIN_SPEC_CAP_INTELLIGENT_BOX = 9,// Intelligent box
    EM_LOGIN_SPEC_CAP_NO_CONFIG = 10,// Not config connection
    EM_LOGIN_SPEC_CAP_U_LOGIN = 11,// Utmp login
    EM_LOGIN_SPEC_CAP_LDAP = 12,// LDAP
    EM_LOGIN_SPEC_CAP_AD = 13,// AD
    EM_LOGIN_SPEC_CAP_RADIUS = 14,// Radius
    EM_LOGIN_SPEC_CAP_SOCKET_5 = 15,// Socket5
    EM_LOGIN_SPEC_CAP_CLOUD = 16,// Cloud login
    EM_LOGIN_SPEC_CAP_AUTH_TWICE = 17,// Auth twice
    EM_LOGIN_SPEC_CAP_TS = 18,// TS stream
    EM_LOGIN_SPEC_CAP_P2P = 19,// P2P
    EM_LOGIN_SPEC_CAP_MOBILE = 20,// Mobile
    EM_LOGIN_SPEC_CAP_INVALID = 21
}
declare enum DH_RealPlayType {
    DH_RType_Realplay = 0,// Real-time preview
    DH_RType_Multiplay = 1,// Multi-play
    DH_RType_Realplay_0 = 2,// Real-time monitor-main stream
    DH_RType_Realplay_1 = 3,// Real-time monitor-extra stream 1
    DH_RType_Realplay_2 = 4,// Real-time monitor-extra stream 2
    DH_RType_Realplay_3 = 5,// Real-time monitor-extra stream 3
    DH_RType_Multiplay_1 = 6,// Multi-play-1
    DH_RType_Multiplay_2 = 7,// Multi-play-2
    DH_RType_Multiplay_3 = 8,// Multi-play-3
    DH_RType_Realplay_4 = 9
}
declare class IntelbrasNetSDK {
    private lib;
    private isInitialized;
    private disconnectCallback;
    constructor();
    /**
     * Inicializa o SDK
     */
    init(): boolean;
    /**
     * Faz login no DVR
     */
    login(ip: string, port: number, username: string, password: string): number;
    /**
     * Faz logout do DVR
     */
    logout(loginHandle: number): boolean;
    /**
     * Inicia visualização em tempo real
     */
    startRealPlay(loginHandle: number, channel?: number): number;
    /**
     * Para visualização em tempo real
     */
    stopRealPlay(realHandle: number): boolean;
    /**
     * Controla PTZ da câmera
     */
    ptzControl(loginHandle: number, channel: number, command: number, speed?: number): boolean;
    /**
     * Captura snapshot
     */
    captureSnapshot(realHandle: number, filePath: string): boolean;
    /**
     * Limpa recursos do SDK
     */
    cleanup(): void;
    /**
     * Retorna mensagem de erro de login
     */
    private getLoginErrorMessage;
}
export declare enum PTZCommand {
    PTZ_UP_CONTROL = 0,
    PTZ_DOWN_CONTROL = 1,
    PTZ_LEFT_CONTROL = 2,
    PTZ_RIGHT_CONTROL = 3,
    PTZ_ZOOM_ADD_CONTROL = 4,// Zoom in
    PTZ_ZOOM_DEC_CONTROL = 5,// Zoom out
    PTZ_FOCUS_ADD_CONTROL = 6,// Focus far
    PTZ_FOCUS_DEC_CONTROL = 7,// Focus near
    PTZ_IRIS_ENLARGE_CONTROL = 8,// Iris open
    PTZ_IRIS_REDUCE_CONTROL = 9,// Iris close
    PTZ_UP_LEFT_CONTROL = 10,
    PTZ_UP_RIGHT_CONTROL = 11,
    PTZ_DOWN_LEFT_CONTROL = 12,
    PTZ_DOWN_RIGHT_CONTROL = 13,
    PTZ_POINT_SET_CONTROL = 100,// Set preset
    PTZ_POINT_MOVE_CONTROL = 101,// Go to preset
    PTZ_POINT_DEL_CONTROL = 102
}
export default IntelbrasNetSDK;
export { EM_LOGIN_SPAC_CAP_TYPE, DH_RealPlayType };
//# sourceMappingURL=intelbras-netsdk.d.ts.map
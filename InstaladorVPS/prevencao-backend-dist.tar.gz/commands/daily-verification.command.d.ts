/**
 * Comando unificado de verificação diária
 *
 * Combina validação de vendas + verificação de bipagens + notificações
 * em um único fluxo otimizado
 */
export declare class DailyVerificationCommand {
    static execute(args: string[]): Promise<void>;
    /**
     * Processa bipagens: identifica as que não tiveram venda e notifica (se notify=true)
     */
    private static processBipages;
    /**
     * Processa vendas: faz matching com bipagens e salva em sells
     */
    private static processSales;
    private static parseArguments;
    private static validateArguments;
    private static printFinalReport;
}
//# sourceMappingURL=daily-verification.command.d.ts.map
export declare class Company {
    id: string;
    nomeFantasia: string;
    razaoSocial: string;
    cnpj: string;
    responsavelNome?: string;
    responsavelEmail?: string;
    responsavelTelefone?: string;
    cep?: string;
    rua?: string;
    numero?: string;
    complemento?: string;
    bairro?: string;
    cidade?: string;
    estado?: string;
    telefone?: string;
    email?: string;
    active: boolean;
    createdAt: Date;
    updatedAt: Date;
}
//# sourceMappingURL=Company.d.ts.map
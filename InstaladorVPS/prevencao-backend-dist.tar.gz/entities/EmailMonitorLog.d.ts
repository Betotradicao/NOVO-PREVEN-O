export declare class EmailMonitorLog {
    id: string;
    email_subject: string;
    sender: string;
    email_body: string | null;
    status: string;
    error_message: string | null;
    has_attachment: boolean;
    whatsapp_group_id: string | null;
    image_path: string | null;
    processed_at: Date;
}
//# sourceMappingURL=EmailMonitorLog.d.ts.map
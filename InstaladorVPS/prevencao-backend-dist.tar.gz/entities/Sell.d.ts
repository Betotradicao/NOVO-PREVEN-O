import { Product } from './Product';
import { Bip } from './Bip';
export declare class Sell {
    id: number;
    activatedProductId: number;
    productId: string;
    productDescription: string;
    sellDate: Date;
    sellValueCents: number;
    productWeight: number;
    bipId: number | null;
    numCupomFiscal: number | null;
    pointOfSaleCode: number | null;
    discountCents: number;
    status: 'verified' | 'not_verified' | 'cancelled';
    createdAt: Date;
    updatedAt: Date;
    activatedProduct: Product;
    bip: Bip | null;
    get sellValue(): number;
    get discountValue(): number;
    get finalValue(): number;
    get statusDescription(): string;
}
//# sourceMappingURL=Sell.d.ts.map
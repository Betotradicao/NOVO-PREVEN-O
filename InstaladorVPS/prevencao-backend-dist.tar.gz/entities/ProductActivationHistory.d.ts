import { User } from './User';
import { Product } from './Product';
export declare class ProductActivationHistory {
    id: number;
    user_id: string;
    product_id: number;
    active: boolean;
    created_at: Date;
    user: User;
    product: Product;
}
//# sourceMappingURL=ProductActivationHistory.d.ts.map
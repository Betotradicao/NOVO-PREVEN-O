import { Equipment } from './Equipment';
import { Employee } from './Employee';
export declare class EquipmentSession {
    id: string;
    equipment_id: number;
    equipment: Equipment;
    employee_id: string;
    employee: Employee;
    logged_in_at: Date;
    logged_out_at: Date | null;
    active: boolean;
    created_at: Date;
    updated_at: Date;
}
//# sourceMappingURL=EquipmentSession.d.ts.map
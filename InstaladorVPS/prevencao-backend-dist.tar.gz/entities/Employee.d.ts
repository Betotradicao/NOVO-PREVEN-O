import { Sector } from './Sector';
export declare class Employee {
    id: string;
    name: string;
    avatar: string | null;
    sector_id: number;
    sector: Sector;
    function_description: string;
    username: string;
    password: string;
    first_access: boolean;
    barcode: string;
    active: boolean;
    created_at: Date;
    updated_at: Date;
}
//# sourceMappingURL=Employee.d.ts.map
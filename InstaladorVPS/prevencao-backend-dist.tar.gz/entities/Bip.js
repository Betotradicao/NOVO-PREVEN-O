"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bip = exports.MotivoCancelamento = exports.BipStatus = void 0;
const typeorm_1 = require("typeorm");
const Equipment_1 = require("./Equipment");
const Employee_1 = require("./Employee");
var BipStatus;
(function (BipStatus) {
    BipStatus["PENDING"] = "pending";
    BipStatus["VERIFIED"] = "verified";
    BipStatus["CANCELLED"] = "cancelled";
})(BipStatus || (exports.BipStatus = BipStatus = {}));
var MotivoCancelamento;
(function (MotivoCancelamento) {
    MotivoCancelamento["PRODUTO_ABANDONADO"] = "produto_abandonado";
    MotivoCancelamento["FALTA_CANCELAMENTO"] = "falta_cancelamento";
    MotivoCancelamento["DEVOLUCAO_MERCADORIA"] = "devolucao_mercadoria";
    MotivoCancelamento["ERRO_OPERADOR"] = "erro_operador";
    MotivoCancelamento["ERRO_BALCONISTA"] = "erro_balconista";
    MotivoCancelamento["FURTO"] = "furto";
})(MotivoCancelamento || (exports.MotivoCancelamento = MotivoCancelamento = {}));
let Bip = class Bip {
    id;
    ean;
    event_date;
    bip_price_cents;
    product_id;
    product_description;
    product_full_price_cents_kg;
    product_discount_price_cents_kg;
    bip_weight;
    tax_cupon;
    status;
    notified_at;
    equipment_id;
    equipment;
    employee_id;
    employee;
    motivo_cancelamento;
    employee_responsavel_id;
    employee_responsavel;
    video_url;
    image_url;
};
exports.Bip = Bip;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Bip.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20 }),
    __metadata("design:type", String)
], Bip.prototype, "ean", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp' }),
    __metadata("design:type", Date)
], Bip.prototype, "event_date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'integer' }),
    __metadata("design:type", Number)
], Bip.prototype, "bip_price_cents", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20 }),
    __metadata("design:type", String)
], Bip.prototype, "product_id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "product_description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'integer', nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "product_full_price_cents_kg", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'integer', nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "product_discount_price_cents_kg", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'numeric', precision: 12, scale: 3, nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "bip_weight", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "tax_cupon", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 20,
        default: BipStatus.PENDING,
        enum: BipStatus
    }),
    __metadata("design:type", String)
], Bip.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "notified_at", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", Number)
], Bip.prototype, "equipment_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => Equipment_1.Equipment, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'equipment_id' }),
    __metadata("design:type", Equipment_1.Equipment)
], Bip.prototype, "equipment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "employee_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => Employee_1.Employee, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'employee_id' }),
    __metadata("design:type", Object)
], Bip.prototype, "employee", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 50,
        nullable: true,
        enum: MotivoCancelamento
    }),
    __metadata("design:type", Object)
], Bip.prototype, "motivo_cancelamento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "employee_responsavel_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => Employee_1.Employee, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'employee_responsavel_id' }),
    __metadata("design:type", Object)
], Bip.prototype, "employee_responsavel", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "video_url", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true }),
    __metadata("design:type", Object)
], Bip.prototype, "image_url", void 0);
exports.Bip = Bip = __decorate([
    (0, typeorm_1.Entity)('bips'),
    (0, typeorm_1.Check)(`status IN ('verified', 'pending', 'cancelled')`)
], Bip);
//# sourceMappingURL=Bip.js.map
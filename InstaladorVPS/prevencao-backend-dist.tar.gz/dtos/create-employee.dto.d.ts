export declare class CreateEmployeeDto {
    name: string;
    sector_id: number;
    function_description: string;
    username: string;
    password: string;
}
export declare function validateCreateEmployee(data: any): {
    valid: boolean;
    errors?: string[];
};
//# sourceMappingURL=create-employee.dto.d.ts.map
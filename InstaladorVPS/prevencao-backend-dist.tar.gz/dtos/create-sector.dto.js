"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateSectorDto = void 0;
exports.validateCreateSector = validateCreateSector;
class CreateSectorDto {
    name;
    color_hash;
}
exports.CreateSectorDto = CreateSectorDto;
function validateCreateSector(data) {
    const errors = [];
    if (!data.name || typeof data.name !== 'string' || data.name.trim().length === 0) {
        errors.push('Name is required and must be a non-empty string');
    }
    if (data.name && data.name.length < 3) {
        errors.push('Name must be at least 3 characters long');
    }
    if (data.name && data.name.length > 255) {
        errors.push('Name must not exceed 255 characters');
    }
    if (data.color_hash && typeof data.color_hash !== 'string') {
        errors.push('Color hash must be a string');
    }
    if (data.color_hash && !/^#[0-9A-F]{6}$/i.test(data.color_hash)) {
        errors.push('Color hash must be in format #RRGGBB');
    }
    return {
        valid: errors.length === 0,
        errors: errors.length > 0 ? errors : undefined
    };
}
//# sourceMappingURL=create-sector.dto.js.map
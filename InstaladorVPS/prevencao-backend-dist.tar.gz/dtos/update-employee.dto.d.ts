export declare class UpdateEmployeeDto {
    name?: string;
    sector_id?: number;
    function_description?: string;
    username?: string;
}
export declare function validateUpdateEmployee(data: any): {
    valid: boolean;
    errors?: string[];
};
//# sourceMappingURL=update-employee.dto.d.ts.map
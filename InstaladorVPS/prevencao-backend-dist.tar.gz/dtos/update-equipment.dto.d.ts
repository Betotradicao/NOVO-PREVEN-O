export interface UpdateEquipmentDto {
    sector_id?: number;
    color_hash?: string;
    description?: string;
}
export declare function validateUpdateEquipment(data: any): {
    valid: boolean;
    errors?: string[];
};
//# sourceMappingURL=update-equipment.dto.d.ts.map
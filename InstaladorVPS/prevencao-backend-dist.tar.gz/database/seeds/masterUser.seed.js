"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedMasterUser = seedMasterUser;
const bcrypt_1 = __importDefault(require("bcrypt"));
const User_1 = require("../../entities/User");
const Company_1 = require("../../entities/Company");
const Configuration_1 = require("../../entities/Configuration");
/**
 * Seed completo do sistema
 * Cria automaticamente:
 * - Empresa padrão
 * - Usuário master "Beto"
 * - Configurações essenciais do sistema
 */
async function seedMasterUser(dataSource) {
    try {
        console.log('🌱 Iniciando seed do sistema...');
        const userRepository = dataSource.getRepository(User_1.User);
        const companyRepository = dataSource.getRepository(Company_1.Company);
        const configRepository = dataSource.getRepository(Configuration_1.Configuration);
        // Verificar se já existe algum usuário master
        const existingMaster = await userRepository.findOne({
            where: { isMaster: true }
        });
        if (existingMaster) {
            console.log('✅ Sistema já inicializado. Pulando seed...');
            return;
        }
        console.log('🏢 Criando empresa padrão...');
        // Criar empresa padrão
        const company = companyRepository.create({
            nomeFantasia: 'Empresa Padrão',
            razaoSocial: 'Empresa Padrão LTDA',
            cnpj: '00000000000000'
        });
        await companyRepository.save(company);
        console.log('✅ Empresa criada:', company.nomeFantasia);
        console.log('👤 Criando usuário master...');
        // Hash da senha
        const hashedPassword = await bcrypt_1.default.hash('Beto3107', 10);
        // Criar usuário master vinculado à empresa
        const masterUser = userRepository.create({
            name: 'Beto',
            username: 'Beto',
            email: 'admin@prevencao.com.br',
            password: hashedPassword,
            role: User_1.UserRole.MASTER,
            isMaster: true,
            companyId: company.id
        });
        await userRepository.save(masterUser);
        console.log('✅ Usuário master criado com sucesso!');
        console.log('📝 Credenciais:');
        console.log('   Usuário: Beto');
        console.log('   Senha: Beto3107');
        console.log('⚙️  Criando configurações do sistema...');
        // Configurações essenciais
        const configs = [
            { key: 'system_initialized', value: 'true' },
            { key: 'email_monitor_enabled', value: 'false' }
        ];
        for (const config of configs) {
            const existing = await configRepository.findOne({ where: { key: config.key } });
            if (!existing) {
                const newConfig = configRepository.create(config);
                await configRepository.save(newConfig);
                console.log(`   ✓ ${config.key}: ${config.value}`);
            }
        }
        console.log('✅ Seed completo! Sistema pronto para uso.');
    }
    catch (error) {
        console.error('❌ Erro ao executar seed:', error);
        // Não lançar erro para não quebrar a aplicação
    }
}
//# sourceMappingURL=masterUser.seed.js.map
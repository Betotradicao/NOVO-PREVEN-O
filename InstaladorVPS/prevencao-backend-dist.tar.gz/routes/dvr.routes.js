"use strict";
/**
 * Rotas para controle do DVR via NetSDK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const dvr_controller_1 = __importDefault(require("../controllers/dvr.controller"));
const auth_middleware_1 = require("../middlewares/auth.middleware");
const router = (0, express_1.Router)();
// Todas as rotas requerem autenticação
router.use(auth_middleware_1.authMiddleware);
/**
 * @swagger
 * /api/dvr/test:
 *   post:
 *     summary: Testa conexão com o DVR
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Resultado do teste de conexão
 */
router.post('/test', dvr_controller_1.default.testConnection);
/**
 * @swagger
 * /api/dvr/status:
 *   get:
 *     summary: Obtém status da conexão com o DVR
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Status da conexão
 */
router.get('/status', dvr_controller_1.default.getStatus);
/**
 * @swagger
 * /api/dvr/snapshot:
 *   post:
 *     summary: Captura snapshot de um canal
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               channel:
 *                 type: integer
 *                 description: Número do canal (0-15)
 *                 default: 0
 *     responses:
 *       200:
 *         description: Snapshot capturado com sucesso
 */
router.post('/snapshot', dvr_controller_1.default.captureSnapshot);
/**
 * @swagger
 * /api/dvr/ptz/control:
 *   post:
 *     summary: Envia comando PTZ genérico
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - channel
 *               - command
 *             properties:
 *               channel:
 *                 type: integer
 *                 description: Número do canal
 *               command:
 *                 type: integer
 *                 description: Código do comando PTZ
 *               speed:
 *                 type: integer
 *                 description: Velocidade (1-8)
 *                 default: 4
 *     responses:
 *       200:
 *         description: Comando enviado com sucesso
 */
router.post('/ptz/control', dvr_controller_1.default.controlPTZ);
/**
 * @swagger
 * /api/dvr/ptz/up:
 *   post:
 *     summary: Move câmera PTZ para cima
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - channel
 *             properties:
 *               channel:
 *                 type: integer
 *               speed:
 *                 type: integer
 *                 default: 4
 *     responses:
 *       200:
 *         description: PTZ movido para cima
 */
router.post('/ptz/up', dvr_controller_1.default.movePTZUp);
/**
 * @swagger
 * /api/dvr/ptz/down:
 *   post:
 *     summary: Move câmera PTZ para baixo
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - channel
 *             properties:
 *               channel:
 *                 type: integer
 *               speed:
 *                 type: integer
 *                 default: 4
 *     responses:
 *       200:
 *         description: PTZ movido para baixo
 */
router.post('/ptz/down', dvr_controller_1.default.movePTZDown);
/**
 * @swagger
 * /api/dvr/ptz/left:
 *   post:
 *     summary: Move câmera PTZ para esquerda
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 */
router.post('/ptz/left', dvr_controller_1.default.movePTZLeft);
/**
 * @swagger
 * /api/dvr/ptz/right:
 *   post:
 *     summary: Move câmera PTZ para direita
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 */
router.post('/ptz/right', dvr_controller_1.default.movePTZRight);
/**
 * @swagger
 * /api/dvr/ptz/zoom-in:
 *   post:
 *     summary: Aplica zoom in na câmera
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 */
router.post('/ptz/zoom-in', dvr_controller_1.default.ptzZoomIn);
/**
 * @swagger
 * /api/dvr/ptz/zoom-out:
 *   post:
 *     summary: Aplica zoom out na câmera
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 */
router.post('/ptz/zoom-out', dvr_controller_1.default.ptzZoomOut);
/**
 * @swagger
 * /api/dvr/ptz/preset/set:
 *   post:
 *     summary: Define um preset PTZ
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - channel
 *               - presetNumber
 *             properties:
 *               channel:
 *                 type: integer
 *               presetNumber:
 *                 type: integer
 *                 description: Número do preset (1-255)
 *     responses:
 *       200:
 *         description: Preset definido com sucesso
 */
router.post('/ptz/preset/set', dvr_controller_1.default.setPTZPreset);
/**
 * @swagger
 * /api/dvr/ptz/preset/goto:
 *   post:
 *     summary: Move câmera para um preset
 *     tags: [DVR]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - channel
 *               - presetNumber
 *             properties:
 *               channel:
 *                 type: integer
 *               presetNumber:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Movendo para preset
 */
router.post('/ptz/preset/goto', dvr_controller_1.default.gotoPTZPreset);
exports.default = router;
//# sourceMappingURL=dvr.routes.js.map
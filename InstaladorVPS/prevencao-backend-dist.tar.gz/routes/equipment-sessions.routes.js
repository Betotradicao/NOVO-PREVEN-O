"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const equipment_sessions_controller_1 = require("../controllers/equipment-sessions.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// GET routes - available for all authenticated users (for viewing scanner status)
router.get('/active', auth_1.authenticateToken, equipment_sessions_controller_1.EquipmentSessionsController.getAllActiveSessions);
router.get('/equipment/:equipmentId', auth_1.authenticateToken, equipment_sessions_controller_1.EquipmentSessionsController.getActiveSessionByEquipment);
router.get('/equipment/:equipmentId/history', auth_1.authenticateToken, equipment_sessions_controller_1.EquipmentSessionsController.getSessionHistory);
// POST routes - admin only (for manual login/logout)
router.post('/login', auth_1.authenticateToken, auth_1.isAdmin, equipment_sessions_controller_1.EquipmentSessionsController.loginEmployee);
router.post('/logout/:equipmentId', auth_1.authenticateToken, auth_1.isAdmin, equipment_sessions_controller_1.EquipmentSessionsController.logoutEmployee);
exports.default = router;
//# sourceMappingURL=equipment-sessions.routes.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const configurations_controller_1 = require("../controllers/configurations.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
const configurationsController = new configurations_controller_1.ConfigurationsController();
// Todas as rotas requerem autenticação
router.get('/', auth_1.authenticateToken, configurationsController.index.bind(configurationsController));
// Rotas específicas para email (devem vir ANTES da rota /:key)
router.get('/email', auth_1.authenticateToken, configurationsController.getEmailConfig.bind(configurationsController));
router.put('/email', auth_1.authenticateToken, configurationsController.updateEmailConfig.bind(configurationsController));
// Rota genérica por chave (deve vir POR ÚLTIMO)
router.get('/:key', auth_1.authenticateToken, configurationsController.show.bind(configurationsController));
router.put('/:key', auth_1.authenticateToken, configurationsController.update.bind(configurationsController));
exports.default = router;
//# sourceMappingURL=configurations.routes.js.map
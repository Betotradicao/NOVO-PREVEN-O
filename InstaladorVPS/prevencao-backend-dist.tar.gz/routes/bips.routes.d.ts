import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=bips.routes.d.ts.map
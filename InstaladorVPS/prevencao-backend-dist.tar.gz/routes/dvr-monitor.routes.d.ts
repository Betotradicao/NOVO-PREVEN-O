/**
 * 🔍 Rotas para Monitor de Email DVR
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=dvr-monitor.routes.d.ts.map
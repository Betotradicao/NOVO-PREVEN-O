"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const sectors_controller_1 = require("../controllers/sectors.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// List sectors - available for all authenticated users (for filters)
router.get('/', auth_1.authenticateToken, sectors_controller_1.SectorsController.getAll);
// Admin-only routes require authentication and admin access
router.get('/:id', auth_1.authenticateToken, auth_1.isAdmin, sectors_controller_1.SectorsController.getById);
router.post('/', auth_1.authenticateToken, auth_1.isAdmin, sectors_controller_1.SectorsController.create);
router.put('/:id', auth_1.authenticateToken, auth_1.isAdmin, sectors_controller_1.SectorsController.update);
router.patch('/:id/toggle', auth_1.authenticateToken, auth_1.isAdmin, sectors_controller_1.SectorsController.toggle);
exports.default = router;
//# sourceMappingURL=sectors.routes.js.map
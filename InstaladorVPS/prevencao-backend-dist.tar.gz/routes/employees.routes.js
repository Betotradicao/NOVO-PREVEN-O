"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const employees_controller_1 = require("../controllers/employees.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// Configure multer for memory storage (files stored in buffer)
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB limit
    },
    fileFilter: (_req, file, cb) => {
        const allowedMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        if (allowedMimeTypes.includes(file.mimetype)) {
            cb(null, true);
        }
        else {
            cb(new Error('Invalid file type. Only JPEG, PNG, and WebP are allowed'));
        }
    },
});
// Profile routes (for logged-in employee) - must come BEFORE /:id routes
router.get('/me/profile', auth_1.authenticateToken, employees_controller_1.EmployeesController.getProfile);
router.patch('/me/profile', auth_1.authenticateToken, employees_controller_1.EmployeesController.updateProfile);
router.patch('/me/avatar', auth_1.authenticateToken, upload.single('avatar'), employees_controller_1.EmployeesController.updateProfileAvatar);
router.patch('/me/password', auth_1.authenticateToken, employees_controller_1.EmployeesController.changePassword);
// List employees - available for all authenticated users (for filters)
router.get('/', auth_1.authenticateToken, employees_controller_1.EmployeesController.getAll);
// Admin-only routes require authentication and admin access
router.get('/:id', auth_1.authenticateToken, auth_1.isAdmin, employees_controller_1.EmployeesController.getById);
router.post('/', auth_1.authenticateToken, auth_1.isAdmin, employees_controller_1.EmployeesController.create);
router.put('/:id', auth_1.authenticateToken, auth_1.isAdmin, employees_controller_1.EmployeesController.update);
router.patch('/:id/avatar', auth_1.authenticateToken, auth_1.isAdmin, upload.single('avatar'), employees_controller_1.EmployeesController.uploadAvatar);
router.patch('/:id/toggle', auth_1.authenticateToken, auth_1.isAdmin, employees_controller_1.EmployeesController.toggleStatus);
router.post('/:id/reset-password', auth_1.authenticateToken, auth_1.isAdmin, employees_controller_1.EmployeesController.resetPassword);
exports.default = router;
//# sourceMappingURL=employees.routes.js.map
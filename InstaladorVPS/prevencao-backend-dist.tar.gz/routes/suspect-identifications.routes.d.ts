import type { Router as RouterType } from 'express';
declare const router: RouterType;
export default router;
//# sourceMappingURL=suspect-identifications.routes.d.ts.map
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=auth.routes.d.ts.map
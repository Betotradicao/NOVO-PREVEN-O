import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=sales.routes.d.ts.map
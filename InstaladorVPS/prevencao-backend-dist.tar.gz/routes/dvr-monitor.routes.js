"use strict";
/**
 * 🔍 Rotas para Monitor de Email DVR
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const dvrMonitorController = __importStar(require("../controllers/dvr-monitor.controller"));
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// Todas as rotas requerem autenticação
router.use(auth_1.authenticateToken);
/**
 * @swagger
 * /api/dvr-monitor/iniciar:
 *   post:
 *     summary: Iniciar monitor automático de email DVR
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Monitor iniciado com sucesso
 *       400:
 *         description: Monitor já está em execução
 */
router.post('/iniciar', dvrMonitorController.iniciarMonitor);
/**
 * @swagger
 * /api/dvr-monitor/parar:
 *   post:
 *     summary: Parar monitor automático de email DVR
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Monitor parado com sucesso
 */
router.post('/parar', dvrMonitorController.pararMonitor);
/**
 * @swagger
 * /api/dvr-monitor/status:
 *   get:
 *     summary: Obter status e estatísticas do monitor
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Status do monitor
 */
router.get('/status', dvrMonitorController.statusMonitor);
/**
 * @swagger
 * /api/dvr-monitor/verificar:
 *   post:
 *     summary: Forçar verificação manual imediata
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Verificação concluída
 */
router.post('/verificar', dvrMonitorController.verificarAgora);
/**
 * @swagger
 * /api/dvr-monitor/senha-gmail:
 *   post:
 *     summary: Salvar senha correta do Gmail
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               senha:
 *                 type: string
 *                 description: Senha do Gmail
 *     responses:
 *       200:
 *         description: Senha salva com sucesso
 */
router.post('/senha-gmail', dvrMonitorController.salvarSenhaGmail);
/**
 * @swagger
 * /api/dvr-monitor/config:
 *   get:
 *     summary: Obter configurações atuais do DVR
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Configurações do DVR
 */
router.get('/config', dvrMonitorController.obterConfiguracao);
/**
 * @swagger
 * /api/dvr-monitor/config:
 *   post:
 *     summary: Salvar configurações do DVR
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               ip:
 *                 type: string
 *               usuario:
 *                 type: string
 *               senha:
 *                 type: string
 *               intervaloMinutos:
 *                 type: number
 *     responses:
 *       200:
 *         description: Configurações salvas
 */
router.post('/config', dvrMonitorController.salvarConfigDVR);
/**
 * @swagger
 * /api/dvr-monitor/testar-conexao:
 *   post:
 *     summary: Testar conexão com o DVR
 *     tags: [DVR Monitor]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               ip:
 *                 type: string
 *               usuario:
 *                 type: string
 *               senha:
 *                 type: string
 *     responses:
 *       200:
 *         description: Teste de conexão bem-sucedido
 */
router.post('/testar-conexao', dvrMonitorController.testarConexaoDVR);
exports.default = router;
//# sourceMappingURL=dvr-monitor.routes.js.map
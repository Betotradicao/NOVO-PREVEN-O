"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const companies_controller_1 = require("../controllers/companies.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
const companiesController = new companies_controller_1.CompaniesController();
// Rotas públicas para empresa do usuário logado
router.get('/my-company', auth_1.authenticateToken, companiesController.getMyCompany.bind(companiesController));
router.put('/my-company', auth_1.authenticateToken, auth_1.isAdminOrMaster, companiesController.updateMyCompany.bind(companiesController));
// Rotas apenas para master (Beto)
router.get('/', auth_1.authenticateToken, auth_1.isMaster, companiesController.index.bind(companiesController));
router.get('/:id', auth_1.authenticateToken, auth_1.isMaster, companiesController.show.bind(companiesController));
router.post('/', auth_1.authenticateToken, auth_1.isMaster, companiesController.create.bind(companiesController));
router.put('/:id', auth_1.authenticateToken, auth_1.isMaster, companiesController.update.bind(companiesController));
router.delete('/:id', auth_1.authenticateToken, auth_1.isMaster, companiesController.delete.bind(companiesController));
exports.default = router;
//# sourceMappingURL=companies.routes.js.map
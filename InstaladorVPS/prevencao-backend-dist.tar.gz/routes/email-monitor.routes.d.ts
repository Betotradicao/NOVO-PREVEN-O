import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=email-monitor.routes.d.ts.map
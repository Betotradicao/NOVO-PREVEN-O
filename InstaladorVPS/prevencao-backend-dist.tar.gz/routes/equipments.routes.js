"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const equipments_controller_1 = require("../controllers/equipments.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// GET routes - available for all authenticated users (for viewing scanner status)
router.get('/', auth_1.authenticateToken, equipments_controller_1.EquipmentsController.getAll);
router.get('/:id', auth_1.authenticateToken, equipments_controller_1.EquipmentsController.getById);
// Modification routes - admin only
router.put('/:id', auth_1.authenticateToken, auth_1.isAdmin, equipments_controller_1.EquipmentsController.update);
router.patch('/:id/toggle', auth_1.authenticateToken, auth_1.isAdmin, equipments_controller_1.EquipmentsController.toggle);
router.delete('/:id', auth_1.authenticateToken, auth_1.isAdmin, equipments_controller_1.EquipmentsController.delete);
exports.default = router;
//# sourceMappingURL=equipments.routes.js.map
export interface Sale {
    codLoja: number;
    desProduto: string;
    codProduto: string;
    codBarraPrincipal: string;
    dtaSaida: string;
    numCupomFiscal: number;
    codCaixa: number;
    valVenda: number;
    qtdTotalProduto: number;
    valTotalProduto: number;
    totalCusto: number;
    descontoAplicado?: number;
    dataHoraVenda?: string;
    motivoCancelamento?: string;
    funcionarioCancelamento?: string;
    tipoCancelamento?: string;
}
export declare class SalesService {
    private static adjustTimezone;
    static fetchSalesFromERP(fromDate: string, toDate: string): Promise<Sale[]>;
    private static fetchSalesFromIntersolid;
    private static fetchSalesFromZanthus;
    private static processZanthusResponse;
    private static formatDateForSQL;
    private static formatDateFromZanthus;
    static formatDateToERP(date: string): string;
    static validateDateFormat(date: string): boolean;
    static isTodayDate(date: string): boolean;
}
//# sourceMappingURL=sales.service.d.ts.map
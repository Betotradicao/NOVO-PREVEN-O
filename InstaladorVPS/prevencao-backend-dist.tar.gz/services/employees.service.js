"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeesService = void 0;
const database_1 = require("../config/database");
const Employee_1 = require("../entities/Employee");
const Sector_1 = require("../entities/Sector");
const employee_response_dto_1 = require("../dtos/employee-response.dto");
const minio_service_1 = require("./minio.service");
const bcrypt = __importStar(require("bcrypt"));
class EmployeesService {
    /**
     * Generate unique barcode with prefix 3122 + timestamp/sequential
     */
    static async generateBarcode() {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const prefix = '3122';
        // Use timestamp-based generation
        const timestamp = Date.now().toString().slice(-8); // Last 8 digits of timestamp
        let barcode = prefix + timestamp;
        // Check if barcode already exists, if so increment
        let exists = await employeeRepository.findOne({ where: { barcode } });
        let counter = 0;
        while (exists) {
            counter++;
            barcode = prefix + (parseInt(timestamp) + counter).toString();
            exists = await employeeRepository.findOne({ where: { barcode } });
        }
        return barcode;
    }
    /**
     * Find all employees with pagination
     */
    static async findAll(page = 1, limit = 10, onlyActive = false) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const skip = (page - 1) * limit;
        const whereCondition = onlyActive ? { active: true } : {};
        const [employees, total] = await employeeRepository.findAndCount({
            where: whereCondition,
            relations: ['sector'],
            order: { created_at: 'DESC' },
            skip,
            take: limit,
        });
        return {
            data: employees.map(emp => new employee_response_dto_1.EmployeeResponseDto(emp)),
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit),
            },
        };
    }
    /**
     * Find employee by ID
     */
    static async findById(id) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const employee = await employeeRepository.findOne({
            where: { id },
            relations: ['sector'],
        });
        if (!employee) {
            throw new Error('Employee not found');
        }
        return new employee_response_dto_1.EmployeeResponseDto(employee);
    }
    /**
     * Create a new employee
     */
    static async create(data) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const sectorRepository = database_1.AppDataSource.getRepository(Sector_1.Sector);
        // Check if sector exists
        const sector = await sectorRepository.findOne({ where: { id: data.sector_id } });
        if (!sector) {
            throw new Error('Sector not found');
        }
        // Check if sector is active
        if (!sector.active) {
            throw new Error('Cannot assign employee to inactive sector');
        }
        // Check if username already exists
        const existingEmployee = await employeeRepository.findOne({
            where: { username: data.username },
        });
        if (existingEmployee) {
            throw new Error('Username already exists');
        }
        // Hash password
        const hashedPassword = await bcrypt.hash(data.password, 10);
        // Generate unique barcode
        const barcode = await this.generateBarcode();
        const employee = employeeRepository.create({
            name: data.name,
            sector_id: data.sector_id,
            function_description: data.function_description,
            username: data.username,
            password: hashedPassword,
            barcode,
            first_access: true,
            active: true,
        });
        const savedEmployee = await employeeRepository.save(employee);
        // Load sector relation
        const employeeWithSector = await employeeRepository.findOne({
            where: { id: savedEmployee.id },
            relations: ['sector'],
        });
        return new employee_response_dto_1.EmployeeResponseDto(employeeWithSector);
    }
    /**
     * Update employee
     */
    static async update(id, data) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const sectorRepository = database_1.AppDataSource.getRepository(Sector_1.Sector);
        const employee = await employeeRepository.findOne({ where: { id } });
        if (!employee) {
            throw new Error('Employee not found');
        }
        // Check if new username already exists (excluding current employee)
        if (data.username && data.username !== employee.username) {
            const existingEmployee = await employeeRepository.findOne({
                where: { username: data.username },
            });
            if (existingEmployee) {
                throw new Error('Username already exists');
            }
        }
        // Check if new sector exists and is active
        if (data.sector_id && data.sector_id !== employee.sector_id) {
            const sector = await sectorRepository.findOne({ where: { id: data.sector_id } });
            if (!sector) {
                throw new Error('Sector not found');
            }
            if (!sector.active) {
                throw new Error('Cannot assign employee to inactive sector');
            }
        }
        // Update fields
        if (data.name)
            employee.name = data.name;
        if (data.sector_id)
            employee.sector_id = data.sector_id;
        if (data.function_description)
            employee.function_description = data.function_description;
        if (data.username)
            employee.username = data.username;
        const savedEmployee = await employeeRepository.save(employee);
        // Load sector relation
        const employeeWithSector = await employeeRepository.findOne({
            where: { id: savedEmployee.id },
            relations: ['sector'],
        });
        return new employee_response_dto_1.EmployeeResponseDto(employeeWithSector);
    }
    /**
     * Upload or update employee avatar
     */
    static async uploadAvatar(id, file) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const employee = await employeeRepository.findOne({ where: { id } });
        if (!employee) {
            throw new Error('Employee not found');
        }
        // Delete old avatar if exists
        if (employee.avatar) {
            try {
                const oldFileName = minio_service_1.minioService.extractFileNameFromUrl(employee.avatar);
                await minio_service_1.minioService.deleteFile(oldFileName);
            }
            catch (error) {
                console.error('Error deleting old avatar:', error);
                // Continue anyway, don't fail the upload
            }
        }
        // Upload new avatar
        const fileName = `avatar-${id}-${Date.now()}.${file.mimetype.split('/')[1]}`;
        const avatarUrl = await minio_service_1.minioService.uploadFile(fileName, file.buffer, file.mimetype);
        // Update employee
        employee.avatar = avatarUrl;
        await employeeRepository.save(employee);
        // Load sector relation
        const employeeWithSector = await employeeRepository.findOne({
            where: { id },
            relations: ['sector'],
        });
        return new employee_response_dto_1.EmployeeResponseDto(employeeWithSector);
    }
    /**
     * Toggle employee active status
     */
    static async toggleStatus(id) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const employee = await employeeRepository.findOne({ where: { id } });
        if (!employee) {
            throw new Error('Employee not found');
        }
        employee.active = !employee.active;
        await employeeRepository.save(employee);
        // Load sector relation
        const employeeWithSector = await employeeRepository.findOne({
            where: { id },
            relations: ['sector'],
        });
        return new employee_response_dto_1.EmployeeResponseDto(employeeWithSector);
    }
    /**
     * Reset employee password (for first access)
     */
    static async resetPassword(id, newPassword) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const employee = await employeeRepository.findOne({ where: { id } });
        if (!employee) {
            throw new Error('Employee not found');
        }
        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        employee.password = hashedPassword;
        employee.first_access = false;
        await employeeRepository.save(employee);
        return { message: 'Password reset successfully' };
    }
    /**
     * Change employee password (employee changes their own password)
     */
    static async changePassword(id, currentPassword, newPassword) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const employee = await employeeRepository.findOne({ where: { id } });
        if (!employee) {
            throw new Error('Employee not found');
        }
        // Verify current password
        const isValidPassword = await bcrypt.compare(currentPassword, employee.password);
        if (!isValidPassword) {
            throw new Error('Current password is incorrect');
        }
        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        employee.password = hashedPassword;
        employee.first_access = false;
        await employeeRepository.save(employee);
        return { message: 'Password changed successfully' };
    }
    /**
     * Find employee by barcode
     */
    static async findByBarcode(barcode) {
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        const employee = await employeeRepository.findOne({
            where: { barcode, active: true },
            relations: ['sector'],
        });
        return employee;
    }
}
exports.EmployeesService = EmployeesService;
//# sourceMappingURL=employees.service.js.map
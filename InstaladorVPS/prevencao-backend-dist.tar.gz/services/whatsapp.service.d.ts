import { Bip } from '../entities/Bip';
export declare class WhatsAppService {
    private static validateEnvironment;
    /**
     * Envia mensagem via Evolution API
     */
    static sendMessage(phoneNumber: string, message: string): Promise<boolean>;
    /**
     * Gera mensagem formatada baseada no template fornecido
     */
    static generateBipMessage(bip: Bip): string;
    /**
     * Envia notificação de bipagem não encontrada
     */
    static sendBipNotification(bip: Bip): Promise<boolean>;
    /**
     * Envia múltiplas notificações com delay entre elas
     */
    static sendMultipleNotifications(bips: Bip[]): Promise<{
        success: number;
        failed: number;
        successfulBips: Bip[];
    }>;
}
//# sourceMappingURL=whatsapp.service.d.ts.map
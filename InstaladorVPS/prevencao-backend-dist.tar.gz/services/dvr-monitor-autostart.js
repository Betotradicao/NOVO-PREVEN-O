"use strict";
/**
 * Serviço para iniciar automaticamente o DVR Monitor
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.monitorInstance = void 0;
exports.autoStartDVRMonitor = autoStartDVRMonitor;
exports.getMonitorInstance = getMonitorInstance;
exports.setMonitorInstance = setMonitorInstance;
const database_1 = require("../config/database");
const Configuration_1 = require("../entities/Configuration");
const DVREmailMonitor = require('./dvr-email-monitor.js');
// Instância global do monitor (compartilhada com o controller)
exports.monitorInstance = null;
/**
 * Obter configuração do DVR do banco
 */
async function obterConfigDVR() {
    const configRepository = database_1.AppDataSource.getRepository(Configuration_1.Configuration);
    const configs = await configRepository.find({
        where: [
            { key: 'dvr_ip' },
            { key: 'dvr_usuario' },
            { key: 'dvr_senha' },
            { key: 'dvr_monitor_intervalo' },
            { key: 'dvr_email_senha' },
            { key: 'dvr_monitor_auto_start' }
        ]
    });
    const configMap = {};
    configs.forEach(c => {
        configMap[c.key] = c.value;
    });
    return {
        dvr: {
            ip: configMap.dvr_ip || '',
            usuario: configMap.dvr_usuario || 'admin',
            senha: configMap.dvr_senha || ''
        },
        intervaloMinutos: parseInt(configMap.dvr_monitor_intervalo || '360'),
        emailSenha: configMap.dvr_email_senha || '',
        autoStart: configMap.dvr_monitor_auto_start === 'true'
    };
}
/**
 * Iniciar DVR Monitor automaticamente se configurado
 */
async function autoStartDVRMonitor() {
    try {
        // Aguardar 5 segundos após o servidor iniciar
        await new Promise(resolve => setTimeout(resolve, 5000));
        console.log('🔍 Verificando configuração de auto-start do DVR Monitor...');
        const config = await obterConfigDVR();
        // Verificar se auto-start está habilitado
        if (!config.autoStart) {
            console.log('ℹ️ DVR Monitor auto-start desabilitado');
            return;
        }
        // Verificar se configurações básicas estão presentes
        if (!config.dvr.ip || !config.dvr.senha) {
            console.log('⚠️ DVR Monitor auto-start: Configurações incompletas (IP ou senha faltando)');
            return;
        }
        console.log('🚀 Iniciando DVR Monitor automaticamente...');
        // Criar instância do monitor
        exports.monitorInstance = new DVREmailMonitor({
            dvr: config.dvr,
            intervaloMinutos: config.intervaloMinutos || 360
        });
        // Iniciar em background
        await exports.monitorInstance.iniciar();
        console.log(`✅ DVR Monitor iniciado automaticamente (intervalo: ${config.intervaloMinutos} minutos)`);
    }
    catch (error) {
        console.error('❌ Erro ao iniciar DVR Monitor automaticamente:', error.message);
    }
}
/**
 * Obter instância do monitor (para uso no controller)
 */
function getMonitorInstance() {
    return exports.monitorInstance;
}
/**
 * Definir instância do monitor (para uso no controller)
 */
function setMonitorInstance(instance) {
    exports.monitorInstance = instance;
}
//# sourceMappingURL=dvr-monitor-autostart.js.map
import { Bip } from '../entities/Bip';
import { SaleData, VerificationResult } from '../types/verification.types';
export declare class BipVerificationService {
    /**
     * Implementa a lógica de matching do N8N
     * Compara bipagens com vendas para determinar quais verificar e quais notificar
     */
    static processVerificationAndNotification(bips: Bip[], vendas: SaleData[]): VerificationResult;
    /**
     * Processa verificações - atualiza status das bipagens para verified
     * e adiciona tax_cupon da venda correspondente
     */
    static processVerifications(verifications: Array<{
        bip: Bip;
        venda: SaleData;
    }>): Promise<void>;
    /**
     * Processa notificações - atualiza notified_at das bipagens
     */
    static processNotifications(notifications: Bip[]): Promise<void>;
}
//# sourceMappingURL=bip-verification.service.d.ts.map
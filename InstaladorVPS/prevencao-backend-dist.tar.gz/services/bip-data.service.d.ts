import { Bip } from '../entities/Bip';
import { SaleData } from '../types/verification.types';
export declare class BipDataService {
    /**
     * Busca vendas para uma data específica
     * Reutiliza a lógica existente do SalesService
     */
    static fetchSalesForDate(date: string): Promise<SaleData[]>;
    /**
     * Busca bipagens pendentes com notified_at nulo para uma data específica
     */
    static fetchPendingBipagesForDate(date: string): Promise<Bip[]>;
    /**
     * Busca TODAS as bipagens de uma data específica (para matching com vendas)
     */
    static fetchAllBipagesForDate(date: string): Promise<Bip[]>;
}
//# sourceMappingURL=bip-data.service.d.ts.map
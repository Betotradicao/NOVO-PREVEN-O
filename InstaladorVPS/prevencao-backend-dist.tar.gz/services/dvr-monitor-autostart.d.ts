/**
 * Serviço para iniciar automaticamente o DVR Monitor
 */
export declare let monitorInstance: any;
/**
 * Iniciar DVR Monitor automaticamente se configurado
 */
export declare function autoStartDVRMonitor(): Promise<void>;
/**
 * Obter instância do monitor (para uso no controller)
 */
export declare function getMonitorInstance(): any;
/**
 * Definir instância do monitor (para uso no controller)
 */
export declare function setMonitorInstance(instance: any): void;
//# sourceMappingURL=dvr-monitor-autostart.d.ts.map
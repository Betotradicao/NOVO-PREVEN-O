"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BipDataService = void 0;
const database_1 = require("../config/database");
const Bip_1 = require("../entities/Bip");
const sales_service_1 = require("./sales.service");
class BipDataService {
    /**
     * Busca vendas para uma data específica
     * Reutiliza a lógica existente do SalesService
     */
    static async fetchSalesForDate(date) {
        try {
            const formattedDate = sales_service_1.SalesService.formatDateToERP(date);
            const sales = await sales_service_1.SalesService.fetchSalesFromERP(formattedDate, formattedDate);
            return sales;
        }
        catch (error) {
            console.error('❌ Erro ao buscar vendas:', error);
            throw error;
        }
    }
    /**
     * Busca bipagens pendentes com notified_at nulo para uma data específica
     */
    static async fetchPendingBipagesForDate(date) {
        try {
            console.log(`🔍 Buscando bipagens pendentes para ${date}...`);
            const bipRepository = database_1.AppDataSource.getRepository(Bip_1.Bip);
            const bips = await bipRepository
                .createQueryBuilder('bip')
                .where('DATE(bip.event_date) = :date', { date })
                .andWhere('bip.status = :status', { status: 'pending' })
                .andWhere('bip.notified_at IS NULL')
                .getMany();
            console.log(`✅ Encontradas ${bips.length} bipagens pendentes`);
            return bips;
        }
        catch (error) {
            console.error('❌ Erro ao buscar bipagens:', error);
            throw error;
        }
    }
    /**
     * Busca TODAS as bipagens de uma data específica (para matching com vendas)
     */
    static async fetchAllBipagesForDate(date) {
        try {
            const bipRepository = database_1.AppDataSource.getRepository(Bip_1.Bip);
            const bips = await bipRepository
                .createQueryBuilder('bip')
                .where('DATE(bip.event_date) = :date', { date })
                .getMany();
            return bips;
        }
        catch (error) {
            console.error('❌ Erro ao buscar bipagens:', error);
            throw error;
        }
    }
}
exports.BipDataService = BipDataService;
//# sourceMappingURL=bip-data.service.js.map
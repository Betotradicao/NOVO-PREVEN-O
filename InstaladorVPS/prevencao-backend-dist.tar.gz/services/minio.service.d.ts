export declare class MinioService {
    private s3Client;
    private bucketName;
    private endpoint;
    private port;
    private accessKey;
    private secretKey;
    private useSSL;
    constructor();
    /**
     * Initializes or reinitializes the MinIO client with current configuration
     * Loads from database first, falls back to .env if not found
     */
    private initializeClient;
    /**
     * Reinitializes the MinIO client with fresh configuration from database
     * Call this after saving new MinIO configuration
     */
    reinitialize(): Promise<void>;
    /**
     * Ensures the bucket exists, creates it if it doesn't
     * Always applies CORS and public read policy
     * Should be called on application startup
     */
    ensureBucketExists(): Promise<void>;
    /**
     * Uploads a file to MinIO
     * @param fileName The name to save the file as
     * @param fileBuffer The file buffer
     * @param contentType The MIME type of the file
     * @returns The URL of the uploaded file
     */
    uploadFile(fileName: string, fileBuffer: Buffer, contentType: string): Promise<string>;
    /**
     * Deletes a file from MinIO
     * @param fileName The name of the file to delete
     */
    deleteFile(fileName: string): Promise<void>;
    /**
     * Extracts the filename from a MinIO URL
     * @param url The full MinIO URL
     * @returns The filename only
     */
    extractFileNameFromUrl(url: string): string;
}
export declare const minioService: MinioService;
//# sourceMappingURL=minio.service.d.ts.map
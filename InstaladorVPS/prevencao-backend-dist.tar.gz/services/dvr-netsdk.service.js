"use strict";
/**
 * Serviço DVR usando Intelbras NetSDK
 * Substitui a conexão TCP simples por uma integração completa via SDK
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DVRNetSDKService = void 0;
const intelbras_netsdk_1 = __importStar(require("../lib/intelbras-netsdk"));
const configuration_service_1 = require("./configuration.service");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
class DVRNetSDKService {
    static sdk = null;
    static loginHandle = 0;
    static config = null;
    static reconnectTimer = null;
    /**
     * Inicializa o serviço NetSDK
     */
    static async initialize() {
        try {
            // Carregar configurações
            this.config = await this.loadConfig();
            if (!this.config.enabled) {
                console.log('[DVR-NetSDK] Serviço desabilitado nas configurações');
                return;
            }
            // Criar diretório de snapshots se não existir
            if (!fs.existsSync(this.config.snapshotPath)) {
                fs.mkdirSync(this.config.snapshotPath, { recursive: true });
            }
            // Inicializar SDK
            this.sdk = new intelbras_netsdk_1.default();
            const initResult = this.sdk.init();
            if (!initResult) {
                console.error('[DVR-NetSDK] Falha ao inicializar SDK');
                return;
            }
            // Fazer login
            await this.connect();
        }
        catch (error) {
            console.error('[DVR-NetSDK] Erro ao inicializar:', error);
        }
    }
    /**
     * Carrega configurações do banco de dados
     */
    static async loadConfig() {
        const enabled = await configuration_service_1.ConfigurationService.get('dvr_netsdk_enabled', 'false');
        const dvrIp = await configuration_service_1.ConfigurationService.get('dvr_ip', '192.168.1.108');
        const dvrPort = await configuration_service_1.ConfigurationService.get('dvr_port', '37777');
        const username = await configuration_service_1.ConfigurationService.get('dvr_username', 'admin');
        const password = await configuration_service_1.ConfigurationService.get('dvr_password', '');
        const channelCount = await configuration_service_1.ConfigurationService.get('dvr_channel_count', '16');
        const snapshotPath = await configuration_service_1.ConfigurationService.get('dvr_snapshot_path', './uploads/dvr-snapshots');
        return {
            enabled: enabled === 'true',
            dvrIp: String(dvrIp),
            dvrPort: parseInt(String(dvrPort)),
            username: String(username),
            password: String(password),
            channelCount: parseInt(String(channelCount)),
            snapshotPath: String(snapshotPath)
        };
    }
    /**
     * Conecta ao DVR via NetSDK
     */
    static async connect() {
        if (!this.sdk || !this.config) {
            throw new Error('SDK não inicializado');
        }
        console.log(`[DVR-NetSDK] Conectando ao DVR ${this.config.dvrIp}:${this.config.dvrPort}...`);
        this.loginHandle = this.sdk.login(this.config.dvrIp, this.config.dvrPort, this.config.username, this.config.password);
        if (this.loginHandle === 0) {
            console.error('[DVR-NetSDK] Falha ao conectar ao DVR');
            this.scheduleReconnect();
            throw new Error('Falha ao conectar ao DVR');
        }
        console.log(`[DVR-NetSDK] Conectado ao DVR com sucesso. Handle: ${this.loginHandle}`);
    }
    /**
     * Agenda reconexão automática
     */
    static scheduleReconnect() {
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
        }
        this.reconnectTimer = setTimeout(async () => {
            console.log('[DVR-NetSDK] Tentando reconectar...');
            try {
                await this.connect();
            }
            catch (error) {
                console.error('[DVR-NetSDK] Falha ao reconectar:', error);
            }
        }, 30000); // Tenta reconectar após 30 segundos
    }
    /**
     * Captura snapshot de um canal
     */
    static async captureSnapshot(channel = 0) {
        if (!this.sdk || this.loginHandle === 0 || !this.config) {
            console.error('[DVR-NetSDK] DVR não conectado');
            return null;
        }
        try {
            // Iniciar stream do canal
            const realHandle = this.sdk.startRealPlay(this.loginHandle, channel);
            if (realHandle === 0) {
                console.error(`[DVR-NetSDK] Falha ao iniciar stream do canal ${channel}`);
                return null;
            }
            // Aguardar um pouco para o stream estabilizar
            await new Promise(resolve => setTimeout(resolve, 2000));
            // Gerar nome do arquivo
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = `snapshot_ch${channel}_${timestamp}.jpg`;
            const filePath = path.join(this.config.snapshotPath, filename);
            // Capturar snapshot
            const success = this.sdk.captureSnapshot(realHandle, filePath);
            // Parar stream
            this.sdk.stopRealPlay(realHandle);
            if (success && fs.existsSync(filePath)) {
                console.log(`[DVR-NetSDK] Snapshot capturado: ${filePath}`);
                return filePath;
            }
            else {
                console.error('[DVR-NetSDK] Falha ao capturar snapshot');
                return null;
            }
        }
        catch (error) {
            console.error('[DVR-NetSDK] Erro ao capturar snapshot:', error);
            return null;
        }
    }
    /**
     * Controla PTZ da câmera
     */
    static async controlPTZ(channel, command, speed = 4) {
        if (!this.sdk || this.loginHandle === 0) {
            console.error('[DVR-NetSDK] DVR não conectado');
            return false;
        }
        try {
            const success = this.sdk.ptzControl(this.loginHandle, channel, command, speed);
            if (success) {
                console.log(`[DVR-NetSDK] Comando PTZ enviado: ${intelbras_netsdk_1.PTZCommand[command]} (canal ${channel})`);
            }
            return success;
        }
        catch (error) {
            console.error('[DVR-NetSDK] Erro ao controlar PTZ:', error);
            return false;
        }
    }
    /**
     * Move câmera PTZ para cima
     */
    static async movePTZUp(channel, speed = 4) {
        return this.controlPTZ(channel, intelbras_netsdk_1.PTZCommand.PTZ_UP_CONTROL, speed);
    }
    /**
     * Move câmera PTZ para baixo
     */
    static async movePTZDown(channel, speed = 4) {
        return this.controlPTZ(channel, intelbras_netsdk_1.PTZCommand.PTZ_DOWN_CONTROL, speed);
    }
    /**
     * Move câmera PTZ para esquerda
     */
    static async movePTZLeft(channel, speed = 4) {
        return this.controlPTZ(channel, intelbras_netsdk_1.PTZCommand.PTZ_LEFT_CONTROL, speed);
    }
    /**
     * Move câmera PTZ para direita
     */
    static async movePTZRight(channel, speed = 4) {
        return this.controlPTZ(channel, intelbras_netsdk_1.PTZCommand.PTZ_RIGHT_CONTROL, speed);
    }
    /**
     * Zoom in da câmera
     */
    static async ptzZoomIn(channel, speed = 4) {
        return this.controlPTZ(channel, intelbras_netsdk_1.PTZCommand.PTZ_ZOOM_ADD_CONTROL, speed);
    }
    /**
     * Zoom out da câmera
     */
    static async ptzZoomOut(channel, speed = 4) {
        return this.controlPTZ(channel, intelbras_netsdk_1.PTZCommand.PTZ_ZOOM_DEC_CONTROL, speed);
    }
    /**
     * Define preset PTZ
     */
    static async setPTZPreset(channel, presetNumber) {
        if (!this.sdk || this.loginHandle === 0) {
            console.error('[DVR-NetSDK] DVR não conectado');
            return false;
        }
        try {
            const success = this.sdk.ptzControl(this.loginHandle, channel, intelbras_netsdk_1.PTZCommand.PTZ_POINT_SET_CONTROL, presetNumber);
            if (success) {
                console.log(`[DVR-NetSDK] Preset ${presetNumber} definido no canal ${channel}`);
            }
            return success;
        }
        catch (error) {
            console.error('[DVR-NetSDK] Erro ao definir preset:', error);
            return false;
        }
    }
    /**
     * Vai para preset PTZ
     */
    static async gotoPTZPreset(channel, presetNumber) {
        if (!this.sdk || this.loginHandle === 0) {
            console.error('[DVR-NetSDK] DVR não conectado');
            return false;
        }
        try {
            const success = this.sdk.ptzControl(this.loginHandle, channel, intelbras_netsdk_1.PTZCommand.PTZ_POINT_MOVE_CONTROL, presetNumber);
            if (success) {
                console.log(`[DVR-NetSDK] Movendo para preset ${presetNumber} no canal ${channel}`);
            }
            return success;
        }
        catch (error) {
            console.error('[DVR-NetSDK] Erro ao ir para preset:', error);
            return false;
        }
    }
    /**
     * Testa a conexão com o DVR
     */
    static async testConnection() {
        try {
            this.config = await this.loadConfig();
            if (!this.config.enabled) {
                return {
                    success: false,
                    message: 'DVR NetSDK está desabilitado nas configurações'
                };
            }
            // Tentar conectar
            if (!this.sdk) {
                this.sdk = new intelbras_netsdk_1.default();
                this.sdk.init();
            }
            await this.connect();
            if (this.loginHandle > 0) {
                return {
                    success: true,
                    message: `Conexão NetSDK estabelecida com ${this.config.dvrIp}:${this.config.dvrPort}`
                };
            }
            else {
                return {
                    success: false,
                    message: 'Falha ao autenticar no DVR'
                };
            }
        }
        catch (error) {
            return {
                success: false,
                message: `Erro: ${error.message}`
            };
        }
    }
    /**
     * Obtém status da conexão
     */
    static getConnectionStatus() {
        return {
            connected: this.loginHandle > 0,
            loginHandle: this.loginHandle,
            config: this.config
        };
    }
    /**
     * Desconecta do DVR e limpa recursos
     */
    static disconnect() {
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        if (this.sdk && this.loginHandle > 0) {
            this.sdk.logout(this.loginHandle);
            this.loginHandle = 0;
        }
        if (this.sdk) {
            this.sdk.cleanup();
            this.sdk = null;
        }
        console.log('[DVR-NetSDK] Desconectado e recursos liberados');
    }
    /**
     * Processa uma venda (mantido para compatibilidade com o sistema atual)
     * Nota: O NetSDK não envia texto diretamente. Esta função poderia ser
     * adaptada para gravar um log ou capturar snapshot da venda.
     */
    static async processSale(sale) {
        try {
            this.config = await this.loadConfig();
            if (!this.config.enabled) {
                console.log('[DVR-NetSDK] Serviço desabilitado, ignorando venda');
                return false;
            }
            console.log(`[DVR-NetSDK] Processando venda ${sale.numCupomFiscal}`);
            // Aqui você poderia:
            // 1. Capturar snapshot do canal principal no momento da venda
            // 2. Logar a venda com timestamp
            // 3. Enviar comando para outro sistema
            // Exemplo: capturar snapshot
            const snapshotPath = await this.captureSnapshot(0);
            if (snapshotPath) {
                console.log(`[DVR-NetSDK] Snapshot da venda capturado: ${snapshotPath}`);
                return true;
            }
            return false;
        }
        catch (error) {
            console.error('[DVR-NetSDK] Erro ao processar venda:', error);
            return false;
        }
    }
}
exports.DVRNetSDKService = DVRNetSDKService;
exports.default = DVRNetSDKService;
//# sourceMappingURL=dvr-netsdk.service.js.map
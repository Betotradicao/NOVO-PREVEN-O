import multer from 'multer';
export declare class VideoUploadService {
    private uploadDir;
    constructor();
    private ensureUploadDirExists;
    getMulterConfig(): multer.Multer;
    deleteVideo(filename: string): boolean;
    extractFilenameFromUrl(videoUrl: string): string;
}
//# sourceMappingURL=video-upload.service.d.ts.map
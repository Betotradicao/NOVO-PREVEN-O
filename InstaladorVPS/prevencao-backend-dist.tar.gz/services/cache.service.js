"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CacheService = void 0;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
class CacheService {
    static CACHE_DIR = path.join(process.cwd(), 'cache');
    static sanitizeKey(key) {
        return key.replace(/[^a-zA-Z0-9_-]/g, '_');
    }
    static getCacheFilePath(cacheKey) {
        const sanitizedKey = this.sanitizeKey(cacheKey);
        return path.join(this.CACHE_DIR, `${sanitizedKey}.json`);
    }
    static async ensureCacheDir() {
        try {
            await fs.access(this.CACHE_DIR);
        }
        catch {
            await fs.mkdir(this.CACHE_DIR, { recursive: true });
        }
    }
    static async executeWithCache(cacheKey, method) {
        await this.ensureCacheDir();
        const filePath = this.getCacheFilePath(cacheKey);
        const now = new Date();
        try {
            // Try to read existing cache file
            const fileContent = await fs.readFile(filePath, 'utf-8');
            const cacheData = JSON.parse(fileContent);
            const validTo = new Date(cacheData.is_valid_to);
            // Check if cache is still valid (is_valid_to > now)
            if (validTo > now) {
                console.log(`Cache hit for key: ${cacheKey}`);
                return cacheData.cache_data;
            }
            console.log(`Cache expired for key: ${cacheKey}`);
        }
        catch (error) {
            // File doesn't exist or is corrupted
            console.log(`Cache miss for key: ${cacheKey}`);
        }
        // Execute method and cache result
        console.log(`Executing method for key: ${cacheKey}`);
        const result = await method();
        // Set cache expiration to 1 hour from now
        const validTo = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour
        const cacheData = {
            cache_data: result,
            is_valid_to: validTo.toISOString(),
            created_at: now.toISOString()
        };
        // Save to cache file
        await fs.writeFile(filePath, JSON.stringify(cacheData, null, 2));
        console.log(`Cached result for key: ${cacheKey}, valid until: ${validTo.toISOString()}`);
        return result;
    }
    static async clearCache(cacheKey) {
        if (cacheKey) {
            // Clear specific cache
            const filePath = this.getCacheFilePath(cacheKey);
            try {
                await fs.unlink(filePath);
                console.log(`Cleared cache for key: ${cacheKey}`);
            }
            catch (error) {
                console.log(`Cache file not found for key: ${cacheKey}`);
            }
        }
        else {
            // Clear all cache
            try {
                const files = await fs.readdir(this.CACHE_DIR);
                for (const file of files) {
                    if (file.endsWith('.json')) {
                        await fs.unlink(path.join(this.CACHE_DIR, file));
                    }
                }
                console.log('Cleared all cache files');
            }
            catch (error) {
                console.log('Error clearing cache directory');
            }
        }
    }
}
exports.CacheService = CacheService;
//# sourceMappingURL=cache.service.js.map
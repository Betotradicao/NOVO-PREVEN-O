import multer from 'multer';
/**
 * Serviço unificado de upload que usa MinIO para armazenamento
 * Substitui ImageUploadService e VideoUploadService
 */
export declare class UploadService {
    /**
     * Configuração do multer para upload de imagens
     */
    getImageMulterConfig(): multer.Multer;
    /**
     * Configuração do multer para upload de vídeos
     */
    getVideoMulterConfig(): multer.Multer;
    /**
     * Faz upload de uma imagem para o MinIO
     * @param file Arquivo do multer
     * @param bipId ID da bipagem
     * @returns URL completa do arquivo no MinIO
     */
    uploadImage(file: Express.Multer.File, bipId: number): Promise<string>;
    /**
     * Faz upload de um vídeo para o MinIO
     * @param file Arquivo do multer
     * @param bipId ID da bipagem
     * @returns URL completa do arquivo no MinIO
     */
    uploadVideo(file: Express.Multer.File, bipId: number): Promise<string>;
    /**
     * Deleta um arquivo do MinIO
     * @param url URL completa do arquivo
     */
    deleteFile(url: string): Promise<void>;
    /**
     * Extrai a extensão do arquivo
     */
    private getFileExtension;
    /**
     * Extrai o nome do arquivo da URL (compatibilidade com código antigo)
     */
    extractFilenameFromUrl(url: string): string;
    /**
     * Deleta imagem (alias para deleteFile, mantido para compatibilidade)
     */
    deleteImage(filenameOrUrl: string): Promise<void>;
    /**
     * Deleta vídeo (alias para deleteFile, mantido para compatibilidade)
     */
    deleteVideo(filenameOrUrl: string): Promise<void>;
}
export declare const uploadService: UploadService;
//# sourceMappingURL=upload.service.d.ts.map
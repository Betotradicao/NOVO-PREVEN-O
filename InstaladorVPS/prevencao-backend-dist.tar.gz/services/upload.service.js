"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadService = exports.UploadService = void 0;
const multer_1 = __importDefault(require("multer"));
const minio_service_1 = require("./minio.service");
/**
 * Serviço unificado de upload que usa MinIO para armazenamento
 * Substitui ImageUploadService e VideoUploadService
 */
class UploadService {
    /**
     * Configuração do multer para upload de imagens
     */
    getImageMulterConfig() {
        const storage = multer_1.default.memoryStorage(); // Armazena em memória para enviar ao MinIO
        const fileFilter = (req, file, cb) => {
            const allowedMimes = [
                'image/jpeg',
                'image/jpg',
                'image/png',
                'image/gif',
                'image/webp',
                'image/bmp',
                'image/tiff'
            ];
            if (allowedMimes.includes(file.mimetype)) {
                cb(null, true);
            }
            else {
                cb(new Error('Apenas arquivos de imagem são permitidos (JPG, PNG, GIF, WebP, BMP, TIFF)'));
            }
        };
        return (0, multer_1.default)({
            storage,
            fileFilter,
            limits: {
                fileSize: 10 * 1024 * 1024 // 10 MB máximo
            }
        });
    }
    /**
     * Configuração do multer para upload de vídeos
     */
    getVideoMulterConfig() {
        const storage = multer_1.default.memoryStorage();
        const fileFilter = (req, file, cb) => {
            const allowedMimes = [
                'video/mp4',
                'video/mpeg',
                'video/quicktime',
                'video/x-msvideo',
                'video/x-matroska',
                'video/webm'
            ];
            if (allowedMimes.includes(file.mimetype)) {
                cb(null, true);
            }
            else {
                cb(new Error('Apenas arquivos de vídeo são permitidos (MP4, AVI, MOV, MKV, WebM)'));
            }
        };
        return (0, multer_1.default)({
            storage,
            fileFilter,
            limits: {
                fileSize: 100 * 1024 * 1024 // 100 MB máximo
            }
        });
    }
    /**
     * Faz upload de uma imagem para o MinIO
     * @param file Arquivo do multer
     * @param bipId ID da bipagem
     * @returns URL completa do arquivo no MinIO
     */
    async uploadImage(file, bipId) {
        const timestamp = Date.now();
        const ext = this.getFileExtension(file.originalname);
        const filename = `bip_${bipId}_${timestamp}${ext}`;
        console.log(`📸 Iniciando upload de imagem: ${filename} (${(file.buffer.length / 1024).toFixed(2)} KB)`);
        const startTime = Date.now();
        try {
            const url = await minio_service_1.minioService.uploadFile(filename, file.buffer, file.mimetype);
            const duration = Date.now() - startTime;
            console.log(`✅ Imagem enviada para MinIO em ${duration}ms: ${filename}`);
            console.log(`🔗 URL: ${url}`);
            return url;
        }
        catch (error) {
            const duration = Date.now() - startTime;
            console.error(`❌ Erro ao enviar imagem após ${duration}ms:`, error);
            throw error;
        }
    }
    /**
     * Faz upload de um vídeo para o MinIO
     * @param file Arquivo do multer
     * @param bipId ID da bipagem
     * @returns URL completa do arquivo no MinIO
     */
    async uploadVideo(file, bipId) {
        const timestamp = Date.now();
        const ext = this.getFileExtension(file.originalname);
        const filename = `bip_${bipId}_${timestamp}${ext}`;
        console.log(`🎥 Iniciando upload de vídeo: ${filename} (${(file.buffer.length / 1024 / 1024).toFixed(2)} MB)`);
        const startTime = Date.now();
        try {
            const url = await minio_service_1.minioService.uploadFile(filename, file.buffer, file.mimetype);
            const duration = Date.now() - startTime;
            console.log(`✅ Vídeo enviado para MinIO em ${duration}ms: ${filename}`);
            console.log(`🔗 URL: ${url}`);
            return url;
        }
        catch (error) {
            const duration = Date.now() - startTime;
            console.error(`❌ Erro ao enviar vídeo após ${duration}ms:`, error);
            throw error;
        }
    }
    /**
     * Deleta um arquivo do MinIO
     * @param url URL completa do arquivo
     */
    async deleteFile(url) {
        if (!url)
            return;
        // Extrair o filename da URL
        const filename = minio_service_1.minioService.extractFileNameFromUrl(url);
        await minio_service_1.minioService.deleteFile(filename);
        console.log(`🗑️ Arquivo deletado do MinIO: ${filename}`);
    }
    /**
     * Extrai a extensão do arquivo
     */
    getFileExtension(filename) {
        const lastDot = filename.lastIndexOf('.');
        return lastDot !== -1 ? filename.substring(lastDot) : '';
    }
    /**
     * Extrai o nome do arquivo da URL (compatibilidade com código antigo)
     */
    extractFilenameFromUrl(url) {
        return minio_service_1.minioService.extractFileNameFromUrl(url);
    }
    /**
     * Deleta imagem (alias para deleteFile, mantido para compatibilidade)
     */
    async deleteImage(filenameOrUrl) {
        return this.deleteFile(filenameOrUrl);
    }
    /**
     * Deleta vídeo (alias para deleteFile, mantido para compatibilidade)
     */
    async deleteVideo(filenameOrUrl) {
        return this.deleteFile(filenameOrUrl);
    }
}
exports.UploadService = UploadService;
// Singleton instance
exports.uploadService = new UploadService();
//# sourceMappingURL=upload.service.js.map
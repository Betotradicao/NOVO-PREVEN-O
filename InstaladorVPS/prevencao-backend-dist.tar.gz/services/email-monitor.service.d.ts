import { EmailMonitorLog } from '../entities/EmailMonitorLog';
export interface EmailMonitorConfig {
    email: string;
    app_password: string;
    subject_filter: string;
    check_interval_seconds: number;
    whatsapp_group_id: string;
    enabled: boolean;
}
export declare class EmailMonitorService {
    private static imap;
    private static isConnected;
    /**
     * Busca configurações do email monitor do banco de dados
     */
    static getConfig(): Promise<EmailMonitorConfig>;
    /**
     * Salva configurações do email monitor
     */
    static saveConfig(config: Partial<EmailMonitorConfig>): Promise<void>;
    /**
     * Conecta ao Gmail via IMAP
     */
    private static connect;
    /**
     * Salva anexo de imagem (JPG, PNG, etc)
     */
    private static saveImageAttachment;
    /**
     * Salva uma cópia permanente da imagem para a galeria
     */
    private static savePermanentImage;
    /**
     * Extrai imagem de PDF
     */
    private static extractImageFromPDF;
    /**
     * Processa um email e envia para WhatsApp
     */
    private static processEmail;
    /**
     * Formata o texto do email com emojis para WhatsApp
     */
    private static formatEmailText;
    /**
     * Envia mensagem e imagem para WhatsApp via Evolution API
     */
    private static sendToWhatsApp;
    /**
     * Verifica novos emails (executado pelo cron)
     */
    static checkNewEmails(): Promise<void>;
    /**
     * Testa conexão com Gmail
     */
    static testConnection(): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Retorna logs de emails processados
     */
    static getLogs(limit?: number): Promise<EmailMonitorLog[]>;
    /**
     * Reprocessa o último email recebido (para testes)
     */
    static reprocessLastEmail(): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Busca grupos do WhatsApp via Evolution API
     */
    static getWhatsAppGroups(): Promise<Array<{
        id: string;
        name: string;
    }>>;
    /**
     * Deletar um log específico e sua imagem associada
     */
    static deleteLog(logId: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
//# sourceMappingURL=email-monitor.service.d.ts.map
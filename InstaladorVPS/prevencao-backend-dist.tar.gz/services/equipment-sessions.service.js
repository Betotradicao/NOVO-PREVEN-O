"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EquipmentSessionsService = void 0;
const database_1 = require("../config/database");
const EquipmentSession_1 = require("../entities/EquipmentSession");
const Equipment_1 = require("../entities/Equipment");
const Employee_1 = require("../entities/Employee");
class EquipmentSessionsService {
    /**
     * Faz login de um colaborador em um equipamento
     * - Desativa QUALQUER sessão ativa naquele equipamento (desloga colaborador anterior)
     * - Cria nova sessão ativa
     */
    static async loginEmployee(equipmentId, employeeId) {
        const sessionRepository = database_1.AppDataSource.getRepository(EquipmentSession_1.EquipmentSession);
        const equipmentRepository = database_1.AppDataSource.getRepository(Equipment_1.Equipment);
        const employeeRepository = database_1.AppDataSource.getRepository(Employee_1.Employee);
        // Verificar se equipamento existe
        const equipment = await equipmentRepository.findOne({ where: { id: equipmentId } });
        if (!equipment) {
            throw new Error('Equipment not found');
        }
        // Verificar se colaborador existe e está ativo
        const employee = await employeeRepository.findOne({ where: { id: employeeId } });
        if (!employee) {
            throw new Error('Employee not found');
        }
        if (!employee.active) {
            throw new Error('Employee is inactive');
        }
        // Desativar QUALQUER sessão ativa naquele equipamento (desloga quem estiver logado)
        await sessionRepository
            .createQueryBuilder()
            .update(EquipmentSession_1.EquipmentSession)
            .set({
            active: false,
            logged_out_at: new Date()
        })
            .where('equipment_id = :equipmentId', { equipmentId })
            .andWhere('active = :active', { active: true })
            .execute();
        // Criar nova sessão
        const newSession = sessionRepository.create({
            equipment_id: equipmentId,
            employee_id: employeeId,
            logged_in_at: new Date(),
            active: true,
        });
        await sessionRepository.save(newSession);
        // Retornar sessão com relacionamentos
        return await sessionRepository.findOne({
            where: { id: newSession.id },
            relations: ['employee', 'employee.sector', 'equipment'],
        });
    }
    /**
     * Faz logout do colaborador logado em um equipamento
     */
    static async logoutEmployee(equipmentId) {
        const sessionRepository = database_1.AppDataSource.getRepository(EquipmentSession_1.EquipmentSession);
        await sessionRepository
            .createQueryBuilder()
            .update(EquipmentSession_1.EquipmentSession)
            .set({
            active: false,
            logged_out_at: new Date()
        })
            .where('equipment_id = :equipmentId', { equipmentId })
            .andWhere('active = :active', { active: true })
            .execute();
    }
    /**
     * Retorna a sessão ativa de um equipamento (colaborador logado)
     */
    static async getActiveSession(equipmentId) {
        const sessionRepository = database_1.AppDataSource.getRepository(EquipmentSession_1.EquipmentSession);
        const session = await sessionRepository.findOne({
            where: {
                equipment_id: equipmentId,
                active: true,
            },
            relations: ['employee', 'employee.sector', 'equipment'],
        });
        return session;
    }
    /**
     * Retorna histórico de sessões de um equipamento
     */
    static async getSessionHistory(equipmentId, filters) {
        const sessionRepository = database_1.AppDataSource.getRepository(EquipmentSession_1.EquipmentSession);
        let query = sessionRepository
            .createQueryBuilder('session')
            .leftJoinAndSelect('session.employee', 'employee')
            .leftJoinAndSelect('employee.sector', 'sector')
            .leftJoinAndSelect('session.equipment', 'equipment')
            .where('session.equipment_id = :equipmentId', { equipmentId });
        // Filtro por colaborador
        if (filters?.employeeId) {
            query = query.andWhere('session.employee_id = :employeeId', {
                employeeId: filters.employeeId
            });
        }
        // Filtro por data
        if (filters?.startDate && filters?.endDate) {
            query = query.andWhere('session.logged_in_at BETWEEN :startDate AND :endDate', {
                startDate: filters.startDate,
                endDate: filters.endDate,
            });
        }
        else if (filters?.startDate) {
            query = query.andWhere('session.logged_in_at >= :startDate', {
                startDate: filters.startDate,
            });
        }
        else if (filters?.endDate) {
            query = query.andWhere('session.logged_in_at <= :endDate', {
                endDate: filters.endDate,
            });
        }
        // Ordenar por data (mais recente primeiro)
        query = query.orderBy('session.logged_in_at', 'DESC');
        // Contar total
        const total = await query.getCount();
        // Paginação
        if (filters?.limit) {
            query = query.limit(filters.limit);
        }
        if (filters?.offset) {
            query = query.offset(filters.offset);
        }
        const sessions = await query.getMany();
        return { sessions, total };
    }
    /**
     * Retorna todas as sessões ativas (para todos os equipamentos)
     */
    static async getAllActiveSessions() {
        const sessionRepository = database_1.AppDataSource.getRepository(EquipmentSession_1.EquipmentSession);
        return await sessionRepository.find({
            where: { active: true },
            relations: ['employee', 'employee.sector', 'equipment', 'equipment.sector'],
            order: { logged_in_at: 'DESC' },
        });
    }
}
exports.EquipmentSessionsService = EquipmentSessionsService;
//# sourceMappingURL=equipment-sessions.service.js.map
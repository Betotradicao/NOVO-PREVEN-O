"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigurationService = void 0;
const database_1 = require("../config/database");
const Configuration_1 = require("../entities/Configuration");
const crypto = __importStar(require("crypto"));
const ENCRYPTION_KEY = process.env.CONFIG_ENCRYPTION_KEY || 'default-key-change-in-production-32bytes';
const ALGORITHM = 'aes-256-cbc';
class ConfigurationService {
    static configRepository = database_1.AppDataSource.getRepository(Configuration_1.Configuration);
    /**
     * Criptografa um valor sensível
     */
    static encrypt(text) {
        const iv = crypto.randomBytes(16);
        const key = Buffer.from(ENCRYPTION_KEY.padEnd(32, '0').slice(0, 32));
        const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return iv.toString('hex') + ':' + encrypted;
    }
    /**
     * Descriptografa um valor sensível
     */
    static decrypt(text) {
        const parts = text.split(':');
        const iv = Buffer.from(parts[0], 'hex');
        const encryptedText = parts[1];
        const key = Buffer.from(ENCRYPTION_KEY.padEnd(32, '0').slice(0, 32));
        const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
        let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }
    /**
     * Salva ou atualiza uma configuração
     */
    static async set(key, value, encrypted = false) {
        const valueToStore = encrypted ? this.encrypt(value) : value;
        let config = await this.configRepository.findOne({ where: { key } });
        if (config) {
            config.value = valueToStore;
            config.encrypted = encrypted;
        }
        else {
            config = this.configRepository.create({
                key,
                value: valueToStore,
                encrypted
            });
        }
        return await this.configRepository.save(config);
    }
    /**
     * Busca uma configuração
     */
    static async get(key, defaultValue = null) {
        const config = await this.configRepository.findOne({ where: { key } });
        if (!config || config.value === null) {
            return defaultValue;
        }
        return config.encrypted ? this.decrypt(config.value) : config.value;
    }
    /**
     * Busca todas as configurações
     */
    static async getAll() {
        const configs = await this.configRepository.find();
        const result = {};
        for (const config of configs) {
            if (config.value !== null) {
                result[config.key] = config.encrypted ? this.decrypt(config.value) : config.value;
            }
        }
        return result;
    }
    /**
     * Salva múltiplas configurações de uma vez
     */
    static async setMany(configs) {
        for (const [key, data] of Object.entries(configs)) {
            await this.set(key, data.value, data.encrypted || false);
        }
    }
    /**
     * Deleta uma configuração
     */
    static async delete(key) {
        const result = await this.configRepository.delete({ key });
        return (result.affected || 0) > 0;
    }
    /**
     * Verifica se uma configuração existe
     */
    static async has(key) {
        const count = await this.configRepository.count({ where: { key } });
        return count > 0;
    }
}
exports.ConfigurationService = ConfigurationService;
//# sourceMappingURL=configuration.service.js.map
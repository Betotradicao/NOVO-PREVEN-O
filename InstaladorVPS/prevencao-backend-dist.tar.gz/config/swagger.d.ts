export declare const swaggerSpec: object;
//# sourceMappingURL=swagger.d.ts.map
import { DataSource } from 'typeorm';
import { Pool } from 'pg';
export declare const AppDataSource: DataSource;
export declare const pool: Pool;
//# sourceMappingURL=database.d.ts.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const database_1 = require("../config/database");
const User_1 = require("../entities/User");
const createUser = async () => {
    const args = process.argv.slice(2);
    if (args.length !== 2) {
        console.error('Usage: npm run create-user <email> <password>');
        process.exit(1);
    }
    const [email, password] = args;
    try {
        await database_1.AppDataSource.initialize();
        const userRepository = database_1.AppDataSource.getRepository(User_1.User);
        const existingUser = await userRepository.findOne({ where: { email } });
        if (existingUser) {
            console.error('Error: User with this email already exists');
            process.exit(1);
        }
        const user = userRepository.create({
            email,
            password
        });
        await userRepository.save(user);
        console.log(`User created successfully:`);
        console.log(`- Email: ${email}`);
        console.log(`- ID: ${user.id}`);
        process.exit(0);
    }
    catch (error) {
        console.error('Error creating user:', error);
        process.exit(1);
    }
};
createUser();
//# sourceMappingURL=create-user.js.map
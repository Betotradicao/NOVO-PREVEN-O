export {};
//# sourceMappingURL=update-beto-password.d.ts.map
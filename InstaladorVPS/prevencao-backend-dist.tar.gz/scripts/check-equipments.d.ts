export {};
//# sourceMappingURL=check-equipments.d.ts.map
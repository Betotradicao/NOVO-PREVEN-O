/**
 * Script de seed para popular configurações iniciais do sistema
 * Executa automaticamente ao iniciar o backend pela primeira vez
 */
declare function seedConfigurations(): Promise<void>;
export default seedConfigurations;
//# sourceMappingURL=seed-configurations.d.ts.map
import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddAddressFieldsToCompanies1765580000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765580000000-AddAddressFieldsToCompanies.d.ts.map
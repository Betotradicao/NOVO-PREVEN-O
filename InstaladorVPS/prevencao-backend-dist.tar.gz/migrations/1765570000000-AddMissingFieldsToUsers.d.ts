import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddMissingFieldsToUsers1765570000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765570000000-AddMissingFieldsToUsers.d.ts.map
import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddDiscountCentsToSells1758756405482 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758756405482-AddDiscountCentsToSells.d.ts.map
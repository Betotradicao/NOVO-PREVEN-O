import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddUniqueIndexToSells1758394113356 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758394113356-AddUniqueIndexToSells.d.ts.map
import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddEmployeeResponsavelToBips1765500000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765500000000-AddEmployeeResponsavelToBips.d.ts.map
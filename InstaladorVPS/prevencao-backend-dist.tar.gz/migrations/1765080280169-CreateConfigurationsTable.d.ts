import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateConfigurationsTable1765080280169 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765080280169-CreateConfigurationsTable.d.ts.map
import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddNotifiedAtToBips1759074839394 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759074839394-AddNotifiedAtToBips.d.ts.map
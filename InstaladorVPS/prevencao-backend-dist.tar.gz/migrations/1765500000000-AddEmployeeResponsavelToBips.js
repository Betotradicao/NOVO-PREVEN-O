"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddEmployeeResponsavelToBips1765500000000 = void 0;
const typeorm_1 = require("typeorm");
class AddEmployeeResponsavelToBips1765500000000 {
    async up(queryRunner) {
        // Adicionar coluna employee_responsavel_id
        await queryRunner.addColumn('bips', new typeorm_1.TableColumn({
            name: 'employee_responsavel_id',
            type: 'uuid',
            isNullable: true,
            comment: 'ID do funcionário responsável pelo erro (quando motivo é ERRO_OPERADOR ou ERRO_BALCONISTA)'
        }));
        // Criar foreign key para employees
        await queryRunner.createForeignKey('bips', new typeorm_1.TableForeignKey({
            columnNames: ['employee_responsavel_id'],
            referencedTableName: 'employees',
            referencedColumnNames: ['id'],
            onDelete: 'SET NULL',
            name: 'FK_bip_employee_responsavel'
        }));
        console.log('✅ Coluna employee_responsavel_id adicionada à tabela bips');
    }
    async down(queryRunner) {
        // Remover foreign key
        await queryRunner.dropForeignKey('bips', 'FK_bip_employee_responsavel');
        // Remover coluna
        await queryRunner.dropColumn('bips', 'employee_responsavel_id');
    }
}
exports.AddEmployeeResponsavelToBips1765500000000 = AddEmployeeResponsavelToBips1765500000000;
//# sourceMappingURL=1765500000000-AddEmployeeResponsavelToBips.js.map
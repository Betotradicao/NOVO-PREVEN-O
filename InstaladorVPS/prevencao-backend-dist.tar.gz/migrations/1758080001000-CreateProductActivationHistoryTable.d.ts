import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateProductActivationHistoryTable1758080001000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758080001000-CreateProductActivationHistoryTable.d.ts.map
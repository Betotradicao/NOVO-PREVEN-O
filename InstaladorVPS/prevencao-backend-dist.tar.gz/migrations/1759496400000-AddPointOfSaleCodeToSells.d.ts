import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddPointOfSaleCodeToSells1759496400000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759496400000-AddPointOfSaleCodeToSells.d.ts.map
import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateEquipmentSessionsTable1759600000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759600000000-CreateEquipmentSessionsTable.d.ts.map
import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AlterSellDateToTimestamp1758923139254 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758923139254-AlterSellDateToTimestamp.d.ts.map
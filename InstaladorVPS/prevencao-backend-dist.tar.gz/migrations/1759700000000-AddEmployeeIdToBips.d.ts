import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddEmployeeIdToBips1759700000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759700000000-AddEmployeeIdToBips.d.ts.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddPointOfSaleCodeToSells1759496400000 = void 0;
class AddPointOfSaleCodeToSells1759496400000 {
    async up(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "sells"
            ADD COLUMN "point_of_sale_code" INTEGER NULL
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "sells"
            DROP COLUMN "point_of_sale_code"
        `);
    }
}
exports.AddPointOfSaleCodeToSells1759496400000 = AddPointOfSaleCodeToSells1759496400000;
//# sourceMappingURL=1759496400000-AddPointOfSaleCodeToSells.js.map
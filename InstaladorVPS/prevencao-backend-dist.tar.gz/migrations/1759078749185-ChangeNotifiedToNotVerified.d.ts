import { MigrationInterface, QueryRunner } from "typeorm";
export declare class ChangeNotifiedToNotVerified1759078749185 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759078749185-ChangeNotifiedToNotVerified.d.ts.map
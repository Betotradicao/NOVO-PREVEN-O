"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddCancelledStatusToBips1758229581610 = void 0;
class AddCancelledStatusToBips1758229581610 {
    async up(queryRunner) {
        // Remover qualquer constraint existente de status
        await queryRunner.query(`ALTER TABLE "bips" DROP CONSTRAINT IF EXISTS "CHK_a5b0a0d72e92b4b0c1c6b8e8c1f0d0e1"`);
        await queryRunner.query(`ALTER TABLE "bips" DROP CONSTRAINT IF EXISTS "bips_status_check"`);
        // Adicionar nova constraint com 'cancelled'
        await queryRunner.query(`ALTER TABLE "bips" ADD CONSTRAINT "CHK_bips_status" CHECK (status IN ('verified', 'notified', 'pending', 'cancelled'))`);
    }
    async down(queryRunner) {
        // Reverter constraint
        await queryRunner.query(`ALTER TABLE "bips" DROP CONSTRAINT "CHK_bips_status"`);
        await queryRunner.query(`ALTER TABLE "bips" ADD CONSTRAINT "CHK_a5b0a0d72e92b4b0c1c6b8e8c1f0d0e1" CHECK (status IN ('verified', 'notified', 'pending'))`);
    }
}
exports.AddCancelledStatusToBips1758229581610 = AddCancelledStatusToBips1758229581610;
//# sourceMappingURL=1758229581610-AddCancelledStatusToBips.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddDiscountCentsToSells1758756405482 = void 0;
class AddDiscountCentsToSells1758756405482 {
    async up(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "sells"
            ADD COLUMN "discount_cents" INTEGER DEFAULT 0
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "sells"
            DROP COLUMN "discount_cents"
        `);
    }
}
exports.AddDiscountCentsToSells1758756405482 = AddDiscountCentsToSells1758756405482;
//# sourceMappingURL=1758756405482-AddDiscountCentsToSells.js.map
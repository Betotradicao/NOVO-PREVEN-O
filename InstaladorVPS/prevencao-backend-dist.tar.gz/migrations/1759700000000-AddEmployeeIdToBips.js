"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddEmployeeIdToBips1759700000000 = void 0;
const typeorm_1 = require("typeorm");
class AddEmployeeIdToBips1759700000000 {
    async up(queryRunner) {
        // Add employee_id column
        await queryRunner.addColumn('bips', new typeorm_1.TableColumn({
            name: 'employee_id',
            type: 'uuid',
            isNullable: true,
        }));
        // Add foreign key to employees table
        await queryRunner.createForeignKey('bips', new typeorm_1.TableForeignKey({
            columnNames: ['employee_id'],
            referencedColumnNames: ['id'],
            referencedTableName: 'employees',
            onDelete: 'SET NULL', // Se colaborador for deletado, manter bipagem mas sem referência
        }));
        // Add index for performance when querying by employee
        await queryRunner.query(`CREATE INDEX idx_bips_employee_id ON bips (employee_id)`);
    }
    async down(queryRunner) {
        // Drop index
        await queryRunner.query(`DROP INDEX IF EXISTS idx_bips_employee_id`);
        // Drop foreign key
        const table = await queryRunner.getTable('bips');
        const foreignKey = table?.foreignKeys.find(fk => fk.columnNames.indexOf('employee_id') !== -1);
        if (foreignKey) {
            await queryRunner.dropForeignKey('bips', foreignKey);
        }
        // Drop column
        await queryRunner.dropColumn('bips', 'employee_id');
    }
}
exports.AddEmployeeIdToBips1759700000000 = AddEmployeeIdToBips1759700000000;
//# sourceMappingURL=1759700000000-AddEmployeeIdToBips.js.map
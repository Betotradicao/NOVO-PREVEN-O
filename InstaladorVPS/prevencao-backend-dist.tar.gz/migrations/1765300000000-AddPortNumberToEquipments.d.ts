import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddPortNumberToEquipments1765300000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765300000000-AddPortNumberToEquipments.d.ts.map
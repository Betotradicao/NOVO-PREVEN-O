import { Request, Response } from 'express';
/**
 * Retorna o status do cron de verificação diária
 */
export declare function getCronStatus(req: Request, res: Response): Promise<void>;
/**
 * Retorna o status do barcode scanner
 */
export declare function getBarcodeStatus(req: Request, res: Response): Promise<void>;
/**
 * Testa conectividade com a API Zanthus
 */
export declare function testZanthusConnection(req: Request, res: Response): Promise<void>;
//# sourceMappingURL=system-status.controller.d.ts.map
import { Request, Response } from 'express';
export declare class PasswordRecoveryController {
    static requestPasswordRecovery(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    static validateResetToken(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    static resetPassword(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=password-recovery.controller.d.ts.map
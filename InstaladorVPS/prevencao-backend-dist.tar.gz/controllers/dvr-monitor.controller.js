"use strict";
/**
 * 🔍 Controller para Monitor de Email DVR
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.testarConexaoDVR = testarConexaoDVR;
exports.obterConfiguracao = obterConfiguracao;
exports.iniciarMonitor = iniciarMonitor;
exports.pararMonitor = pararMonitor;
exports.statusMonitor = statusMonitor;
exports.verificarAgora = verificarAgora;
exports.salvarSenhaGmail = salvarSenhaGmail;
exports.salvarConfigDVR = salvarConfigDVR;
const database_1 = require("../config/database");
const Configuration_1 = require("../entities/Configuration");
const child_process_1 = require("child_process");
const util_1 = require("util");
const execPromise = (0, util_1.promisify)(child_process_1.exec);
const DVREmailMonitor = require('../services/dvr-email-monitor.js');
let monitorInstance = null;
/**
 * Obter configuração do DVR do banco
 */
async function obterConfigDVR() {
    const configRepository = database_1.AppDataSource.getRepository(Configuration_1.Configuration);
    const configs = await configRepository.find({
        where: [
            { key: 'dvr_ip' },
            { key: 'dvr_usuario' },
            { key: 'dvr_senha' },
            { key: 'dvr_monitor_intervalo' },
            { key: 'dvr_email_senha' }
        ]
    });
    const configMap = {};
    configs.forEach(c => {
        configMap[c.key] = c.value;
    });
    return {
        dvr: {
            ip: configMap.dvr_ip || '',
            usuario: configMap.dvr_usuario || 'admin',
            senha: configMap.dvr_senha || ''
        },
        intervaloMinutos: parseInt(configMap.dvr_monitor_intervalo || '360'),
        emailSenha: configMap.dvr_email_senha || ''
    };
}
/**
 * Salvar configuração no banco
 */
async function salvarConfig(key, value, descricao) {
    const configRepository = database_1.AppDataSource.getRepository(Configuration_1.Configuration);
    let config = await configRepository.findOne({ where: { key } });
    if (config) {
        config.value = value;
        config.updated_at = new Date();
    }
    else {
        config = configRepository.create({
            key,
            value,
            encrypted: false
        });
    }
    await configRepository.save(config);
}
/**
 * Testar conexão com DVR
 */
async function testarConexaoDVR(req, res) {
    try {
        const { ip, usuario, senha } = req.body;
        if (!ip || !usuario || !senha) {
            return res.status(400).json({
                error: 'IP, usuário e senha são obrigatórios'
            });
        }
        // Testar conexão via curl
        const url = `http://${ip}/cgi-bin/magicBox.cgi?action=getSystemInfo`;
        const cmd = `curl -u "${usuario}:${senha}" --digest --connect-timeout 5 "${url}" 2>nul`;
        try {
            const { stdout } = await execPromise(cmd);
            if (stdout.includes('processor') || stdout.includes('serialNumber')) {
                res.json({
                    success: true,
                    message: 'Conexão bem-sucedida!',
                    info: stdout
                });
            }
            else {
                res.status(400).json({
                    error: 'DVR respondeu mas dados inválidos',
                    details: stdout
                });
            }
        }
        catch (error) {
            res.status(500).json({
                error: 'Falha ao conectar no DVR',
                details: error.message
            });
        }
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao testar conexão',
            details: error.message
        });
    }
}
/**
 * Obter configurações atuais do DVR
 */
async function obterConfiguracao(req, res) {
    try {
        const config = await obterConfigDVR();
        res.json({
            ip: config.dvr.ip,
            usuario: config.dvr.usuario,
            // Não retornar senha por segurança
            intervaloMinutos: config.intervaloMinutos,
            temSenhaEmail: !!config.emailSenha
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao obter configuração',
            details: error.message
        });
    }
}
/**
 * Iniciar monitor
 */
async function iniciarMonitor(req, res) {
    try {
        if (monitorInstance && monitorInstance.enabled) {
            return res.status(400).json({
                error: 'Monitor já está em execução'
            });
        }
        // Obter configurações do DVR do banco
        const configDVR = await obterConfigDVR();
        // Criar instância do monitor
        monitorInstance = new DVREmailMonitor({
            dvr: configDVR.dvr,
            intervaloMinutos: configDVR.intervaloMinutos || 5
        });
        // Iniciar em background
        monitorInstance.iniciar().catch(console.error);
        res.json({
            success: true,
            message: 'Monitor iniciado com sucesso',
            config: {
                intervaloMinutos: monitorInstance.intervaloMinutos,
                dvr: {
                    ip: monitorInstance.dvr.ip
                }
            }
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao iniciar monitor',
            details: error.message
        });
    }
}
/**
 * Parar monitor
 */
async function pararMonitor(req, res) {
    try {
        if (!monitorInstance || !monitorInstance.enabled) {
            return res.status(400).json({
                error: 'Monitor não está em execução'
            });
        }
        monitorInstance.parar();
        res.json({
            success: true,
            message: 'Monitor parado com sucesso'
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao parar monitor',
            details: error.message
        });
    }
}
/**
 * Obter status e estatísticas do monitor
 */
async function statusMonitor(req, res) {
    try {
        if (!monitorInstance) {
            return res.json({
                ativo: false,
                message: 'Monitor nunca foi iniciado'
            });
        }
        const stats = monitorInstance.getEstatisticas();
        res.json({
            ativo: stats.enabled,
            intervaloMinutos: stats.intervaloMinutos,
            ultimaVerificacao: stats.ultimaVerificacao,
            totalVerificacoes: stats.totalVerificacoes,
            totalCorrecoes: stats.totalCorrecoes,
            ultimaCorrecao: stats.ultimaCorrecao,
            dvr: stats.dvr
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao obter status',
            details: error.message
        });
    }
}
/**
 * Forçar verificação manual
 */
async function verificarAgora(req, res) {
    try {
        if (!monitorInstance) {
            return res.status(400).json({
                error: 'Monitor não está inicializado. Inicie o monitor primeiro.'
            });
        }
        // Executar verificação imediata
        await monitorInstance.verificarESalvar();
        const stats = monitorInstance.getEstatisticas();
        res.json({
            success: true,
            message: 'Verificação manual concluída',
            ultimaVerificacao: stats.ultimaVerificacao,
            totalCorrecoes: stats.totalCorrecoes
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao verificar',
            details: error.message
        });
    }
}
/**
 * Salvar configuração de senha do Gmail
 */
async function salvarSenhaGmail(req, res) {
    try {
        const { senha } = req.body;
        if (!senha) {
            return res.status(400).json({
                error: 'Senha é obrigatória'
            });
        }
        // Salvar no banco
        await salvarConfig('dvr_email_senha', senha, 'Senha correta do Gmail para DVR Intelbras');
        res.json({
            success: true,
            message: 'Senha salva com sucesso'
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao salvar senha',
            details: error.message
        });
    }
}
/**
 * Salvar configurações do DVR
 */
async function salvarConfigDVR(req, res) {
    try {
        const { ip, usuario, senha, intervaloMinutos } = req.body;
        if (!ip || !usuario || !senha) {
            return res.status(400).json({
                error: 'IP, usuário e senha são obrigatórios'
            });
        }
        // Salvar todas as configurações
        await salvarConfig('dvr_ip', ip, 'IP do DVR Intelbras');
        await salvarConfig('dvr_usuario', usuario, 'Usuário do DVR');
        await salvarConfig('dvr_senha', senha, 'Senha do DVR');
        await salvarConfig('dvr_monitor_intervalo', intervaloMinutos.toString(), 'Intervalo de verificação em minutos');
        res.json({
            success: true,
            message: 'Configurações salvas com sucesso'
        });
    }
    catch (error) {
        res.status(500).json({
            error: 'Erro ao salvar configurações',
            details: error.message
        });
    }
}
//# sourceMappingURL=dvr-monitor.controller.js.map
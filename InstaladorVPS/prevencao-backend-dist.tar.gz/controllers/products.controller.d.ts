import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class ProductsController {
    static getProducts(req: AuthRequest, res: Response): Promise<void>;
    static activateProduct(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static bulkActivateProducts(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
//# sourceMappingURL=products.controller.d.ts.map
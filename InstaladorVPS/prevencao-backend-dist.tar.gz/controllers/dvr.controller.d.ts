/**
 * Controlador para operações do DVR via NetSDK
 */
import { Request, Response } from 'express';
export declare class DVRController {
    /**
     * Testa conexão com o DVR
     */
    static testConnection(req: Request, res: Response): Promise<void>;
    /**
     * Obtém status da conexão
     */
    static getStatus(req: Request, res: Response): Promise<void>;
    /**
     * Captura snapshot de um canal
     */
    static captureSnapshot(req: Request, res: Response): Promise<void>;
    /**
     * Controla PTZ da câmera
     */
    static controlPTZ(req: Request, res: Response): Promise<void>;
    /**
     * Move PTZ para cima
     */
    static movePTZUp(req: Request, res: Response): Promise<void>;
    /**
     * Move PTZ para baixo
     */
    static movePTZDown(req: Request, res: Response): Promise<void>;
    /**
     * Move PTZ para esquerda
     */
    static movePTZLeft(req: Request, res: Response): Promise<void>;
    /**
     * Move PTZ para direita
     */
    static movePTZRight(req: Request, res: Response): Promise<void>;
    /**
     * Zoom in da câmera
     */
    static ptzZoomIn(req: Request, res: Response): Promise<void>;
    /**
     * Zoom out da câmera
     */
    static ptzZoomOut(req: Request, res: Response): Promise<void>;
    /**
     * Define preset PTZ
     */
    static setPTZPreset(req: Request, res: Response): Promise<void>;
    /**
     * Vai para preset PTZ
     */
    static gotoPTZPreset(req: Request, res: Response): Promise<void>;
}
export default DVRController;
//# sourceMappingURL=dvr.controller.d.ts.map
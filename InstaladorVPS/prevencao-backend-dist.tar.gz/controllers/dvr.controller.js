"use strict";
/**
 * Controlador para operações do DVR via NetSDK
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DVRController = void 0;
const dvr_netsdk_service_1 = __importDefault(require("../services/dvr-netsdk.service"));
class DVRController {
    /**
     * Testa conexão com o DVR
     */
    static async testConnection(req, res) {
        try {
            const result = await dvr_netsdk_service_1.default.testConnection();
            res.json({
                success: result.success,
                message: result.message
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro ao testar conexão: ${error.message}`
            });
        }
    }
    /**
     * Obtém status da conexão
     */
    static async getStatus(req, res) {
        try {
            const status = dvr_netsdk_service_1.default.getConnectionStatus();
            res.json({
                success: true,
                data: {
                    connected: status.connected,
                    loginHandle: status.loginHandle,
                    config: status.config ? {
                        ip: status.config.dvrIp,
                        port: status.config.dvrPort,
                        username: status.config.username,
                        channelCount: status.config.channelCount
                    } : null
                }
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro ao obter status: ${error.message}`
            });
        }
    }
    /**
     * Captura snapshot de um canal
     */
    static async captureSnapshot(req, res) {
        try {
            const { channel = 0 } = req.body;
            const snapshotPath = await dvr_netsdk_service_1.default.captureSnapshot(channel);
            if (snapshotPath) {
                res.json({
                    success: true,
                    message: 'Snapshot capturado com sucesso',
                    data: {
                        path: snapshotPath,
                        channel
                    }
                });
            }
            else {
                res.status(400).json({
                    success: false,
                    message: 'Falha ao capturar snapshot'
                });
            }
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro ao capturar snapshot: ${error.message}`
            });
        }
    }
    /**
     * Controla PTZ da câmera
     */
    static async controlPTZ(req, res) {
        try {
            const { channel, command, speed = 4 } = req.body;
            if (channel === undefined || command === undefined) {
                res.status(400).json({
                    success: false,
                    message: 'Parâmetros channel e command são obrigatórios'
                });
                return;
            }
            const success = await dvr_netsdk_service_1.default.controlPTZ(channel, command, speed);
            if (success) {
                res.json({
                    success: true,
                    message: 'Comando PTZ enviado com sucesso',
                    data: { channel, command, speed }
                });
            }
            else {
                res.status(400).json({
                    success: false,
                    message: 'Falha ao enviar comando PTZ'
                });
            }
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro ao controlar PTZ: ${error.message}`
            });
        }
    }
    /**
     * Move PTZ para cima
     */
    static async movePTZUp(req, res) {
        try {
            const { channel, speed = 4 } = req.body;
            const success = await dvr_netsdk_service_1.default.movePTZUp(channel, speed);
            res.json({
                success,
                message: success ? 'PTZ movido para cima' : 'Falha ao mover PTZ'
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Move PTZ para baixo
     */
    static async movePTZDown(req, res) {
        try {
            const { channel, speed = 4 } = req.body;
            const success = await dvr_netsdk_service_1.default.movePTZDown(channel, speed);
            res.json({
                success,
                message: success ? 'PTZ movido para baixo' : 'Falha ao mover PTZ'
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Move PTZ para esquerda
     */
    static async movePTZLeft(req, res) {
        try {
            const { channel, speed = 4 } = req.body;
            const success = await dvr_netsdk_service_1.default.movePTZLeft(channel, speed);
            res.json({
                success,
                message: success ? 'PTZ movido para esquerda' : 'Falha ao mover PTZ'
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Move PTZ para direita
     */
    static async movePTZRight(req, res) {
        try {
            const { channel, speed = 4 } = req.body;
            const success = await dvr_netsdk_service_1.default.movePTZRight(channel, speed);
            res.json({
                success,
                message: success ? 'PTZ movido para direita' : 'Falha ao mover PTZ'
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Zoom in da câmera
     */
    static async ptzZoomIn(req, res) {
        try {
            const { channel, speed = 4 } = req.body;
            const success = await dvr_netsdk_service_1.default.ptzZoomIn(channel, speed);
            res.json({
                success,
                message: success ? 'Zoom in aplicado' : 'Falha ao aplicar zoom'
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Zoom out da câmera
     */
    static async ptzZoomOut(req, res) {
        try {
            const { channel, speed = 4 } = req.body;
            const success = await dvr_netsdk_service_1.default.ptzZoomOut(channel, speed);
            res.json({
                success,
                message: success ? 'Zoom out aplicado' : 'Falha ao aplicar zoom'
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Define preset PTZ
     */
    static async setPTZPreset(req, res) {
        try {
            const { channel, presetNumber } = req.body;
            if (channel === undefined || presetNumber === undefined) {
                res.status(400).json({
                    success: false,
                    message: 'Parâmetros channel e presetNumber são obrigatórios'
                });
                return;
            }
            const success = await dvr_netsdk_service_1.default.setPTZPreset(channel, presetNumber);
            res.json({
                success,
                message: success
                    ? `Preset ${presetNumber} definido no canal ${channel}`
                    : 'Falha ao definir preset',
                data: { channel, presetNumber }
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
    /**
     * Vai para preset PTZ
     */
    static async gotoPTZPreset(req, res) {
        try {
            const { channel, presetNumber } = req.body;
            if (channel === undefined || presetNumber === undefined) {
                res.status(400).json({
                    success: false,
                    message: 'Parâmetros channel e presetNumber são obrigatórios'
                });
                return;
            }
            const success = await dvr_netsdk_service_1.default.gotoPTZPreset(channel, presetNumber);
            res.json({
                success,
                message: success
                    ? `Movendo para preset ${presetNumber} no canal ${channel}`
                    : 'Falha ao ir para preset',
                data: { channel, presetNumber }
            });
        }
        catch (error) {
            res.status(500).json({
                success: false,
                message: `Erro: ${error.message}`
            });
        }
    }
}
exports.DVRController = DVRController;
exports.default = DVRController;
//# sourceMappingURL=dvr.controller.js.map
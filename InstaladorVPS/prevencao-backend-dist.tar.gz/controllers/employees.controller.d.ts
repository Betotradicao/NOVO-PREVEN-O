import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class EmployeesController {
    static getAll(req: AuthRequest, res: Response): Promise<void>;
    static getById(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static create(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static update(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static uploadAvatar(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static toggleStatus(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static resetPassword(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static getProfile(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static updateProfile(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static updateProfileAvatar(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static changePassword(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
//# sourceMappingURL=employees.controller.d.ts.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeesController = void 0;
const employees_service_1 = require("../services/employees.service");
const create_employee_dto_1 = require("../dtos/create-employee.dto");
const update_employee_dto_1 = require("../dtos/update-employee.dto");
class EmployeesController {
    static async getAll(req, res) {
        try {
            const page = parseInt(req.query.page) || 1;
            const limit = parseInt(req.query.limit) || 10;
            const onlyActive = req.query.active === 'true';
            const result = await employees_service_1.EmployeesService.findAll(page, limit, onlyActive);
            res.json(result);
        }
        catch (error) {
            console.error('Get all employees error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async getById(req, res) {
        try {
            const { id } = req.params;
            const employee = await employees_service_1.EmployeesService.findById(id);
            res.json(employee);
        }
        catch (error) {
            console.error('Get employee by ID error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async create(req, res) {
        try {
            const validation = (0, create_employee_dto_1.validateCreateEmployee)(req.body);
            if (!validation.valid) {
                return res.status(400).json({ errors: validation.errors });
            }
            const employee = await employees_service_1.EmployeesService.create(req.body);
            res.status(201).json(employee);
        }
        catch (error) {
            console.error('Create employee error:', error);
            if (error.message === 'Username already exists') {
                return res.status(409).json({ error: error.message });
            }
            if (error.message === 'Sector not found') {
                return res.status(404).json({ error: error.message });
            }
            if (error.message === 'Cannot assign employee to inactive sector') {
                return res.status(400).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async update(req, res) {
        try {
            const { id } = req.params;
            const validation = (0, update_employee_dto_1.validateUpdateEmployee)(req.body);
            if (!validation.valid) {
                return res.status(400).json({ errors: validation.errors });
            }
            const employee = await employees_service_1.EmployeesService.update(id, req.body);
            res.json(employee);
        }
        catch (error) {
            console.error('Update employee error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            if (error.message === 'Username already exists') {
                return res.status(409).json({ error: error.message });
            }
            if (error.message === 'Sector not found') {
                return res.status(404).json({ error: error.message });
            }
            if (error.message === 'Cannot assign employee to inactive sector') {
                return res.status(400).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async uploadAvatar(req, res) {
        try {
            const { id } = req.params;
            if (!req.file) {
                return res.status(400).json({ error: 'No file provided' });
            }
            // Validate file type
            const allowedMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
            if (!allowedMimeTypes.includes(req.file.mimetype)) {
                return res.status(400).json({ error: 'Invalid file type. Only JPEG, PNG, and WebP are allowed' });
            }
            // Validate file size (max 5MB)
            const maxSize = 5 * 1024 * 1024;
            if (req.file.size > maxSize) {
                return res.status(400).json({ error: 'File size exceeds 5MB limit' });
            }
            const employee = await employees_service_1.EmployeesService.uploadAvatar(id, req.file);
            res.json(employee);
        }
        catch (error) {
            console.error('Upload avatar error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async toggleStatus(req, res) {
        try {
            const { id } = req.params;
            const employee = await employees_service_1.EmployeesService.toggleStatus(id);
            res.json(employee);
        }
        catch (error) {
            console.error('Toggle employee status error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async resetPassword(req, res) {
        try {
            const { id } = req.params;
            const { newPassword } = req.body;
            if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 6) {
                return res.status(400).json({ error: 'Password must be at least 6 characters long' });
            }
            const result = await employees_service_1.EmployeesService.resetPassword(id, newPassword);
            res.json(result);
        }
        catch (error) {
            console.error('Reset password error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    // Profile methods for logged-in employee
    static async getProfile(req, res) {
        try {
            if (!req.user || req.user.type !== 'employee') {
                return res.status(403).json({ error: 'Only employees can access their profile' });
            }
            const employee = await employees_service_1.EmployeesService.findById(req.user.id);
            res.json(employee);
        }
        catch (error) {
            console.error('Get profile error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async updateProfile(req, res) {
        try {
            if (!req.user || req.user.type !== 'employee') {
                return res.status(403).json({ error: 'Only employees can update their profile' });
            }
            // Only allow name to be updated
            const { name } = req.body;
            if (!name || typeof name !== 'string' || name.trim().length === 0) {
                return res.status(400).json({ error: 'Name is required' });
            }
            const employee = await employees_service_1.EmployeesService.update(req.user.id, { name: name.trim() });
            res.json(employee);
        }
        catch (error) {
            console.error('Update profile error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async updateProfileAvatar(req, res) {
        try {
            if (!req.user || req.user.type !== 'employee') {
                return res.status(403).json({ error: 'Only employees can update their avatar' });
            }
            if (!req.file) {
                return res.status(400).json({ error: 'No file provided' });
            }
            // Validate file type
            const allowedMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
            if (!allowedMimeTypes.includes(req.file.mimetype)) {
                return res.status(400).json({ error: 'Invalid file type. Only JPEG, PNG, and WebP are allowed' });
            }
            // Validate file size (max 5MB)
            const maxSize = 5 * 1024 * 1024;
            if (req.file.size > maxSize) {
                return res.status(400).json({ error: 'File size exceeds 5MB limit' });
            }
            const employee = await employees_service_1.EmployeesService.uploadAvatar(req.user.id, req.file);
            res.json(employee);
        }
        catch (error) {
            console.error('Update profile avatar error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async changePassword(req, res) {
        try {
            if (!req.user || req.user.type !== 'employee') {
                return res.status(403).json({ error: 'Only employees can change their password' });
            }
            const { currentPassword, newPassword } = req.body;
            if (!currentPassword || !newPassword) {
                return res.status(400).json({ error: 'Current password and new password are required' });
            }
            if (typeof newPassword !== 'string' || newPassword.length < 6) {
                return res.status(400).json({ error: 'New password must be at least 6 characters long' });
            }
            const result = await employees_service_1.EmployeesService.changePassword(req.user.id, currentPassword, newPassword);
            res.json(result);
        }
        catch (error) {
            console.error('Change password error:', error);
            if (error.message === 'Employee not found') {
                return res.status(404).json({ error: error.message });
            }
            if (error.message === 'Current password is incorrect') {
                return res.status(401).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}
exports.EmployeesController = EmployeesController;
//# sourceMappingURL=employees.controller.js.map
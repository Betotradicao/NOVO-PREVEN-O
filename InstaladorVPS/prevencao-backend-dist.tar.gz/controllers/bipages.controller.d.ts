import { Request, Response } from 'express';
export declare class BipagesController {
    /**
     * Recebe webhook de bipagem em tempo real
     * Replica toda a lógica do fluxo N8N
     */
    static receiveWebhook(req: Request, res: Response): Promise<void>;
    /**
     * Simula uma venda para conciliar com uma bipagem
     * Útil para testes do simulador
     */
    static simulateSale(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=bipages.controller.d.ts.map
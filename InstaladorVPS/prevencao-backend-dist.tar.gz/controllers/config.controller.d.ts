import { Request, Response } from 'express';
export declare class ConfigController {
    testDatabaseConnection(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    testMinioConnection(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    testZanthusConnection(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    testIntersolidConnection(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    saveConfigurations(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    getConfigurations(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=config.controller.d.ts.map
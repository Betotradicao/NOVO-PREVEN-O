import { Request, Response } from 'express';
export declare class SystemController {
    /**
     * Gera um token aleatório seguro
     */
    private static generateRandomToken;
    /**
     * Caminho do arquivo .env
     */
    private static getEnvPath;
    /**
     * Lê o arquivo .env e retorna o conteúdo
     */
    private static readEnvFile;
    /**
     * Atualiza o arquivo .env com novo token
     */
    private static updateEnvFile;
    /**
     * GET /api/system/token
     * Retorna o token atual (apenas para admins)
     */
    static getToken(req: Request, res: Response): Promise<void>;
    /**
     * POST /api/system/token/generate
     * Gera e atualiza automaticamente um novo token
     */
    static generateToken(req: Request, res: Response): Promise<void>;
    /**
     * PUT /api/system/token
     * Atualiza o token com um valor específico fornecido
     */
    static updateToken(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=system.controller.d.ts.map